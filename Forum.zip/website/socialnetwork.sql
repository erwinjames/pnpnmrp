-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2020 at 04:51 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialnetwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `a_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `aimage` text NOT NULL,
  `bimage` text NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `gender` varchar(11) NOT NULL,
  `dateregister` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `chatfriend`
--

CREATE TABLE `chatfriend` (
  `id` int(11) NOT NULL,
  `myid` int(11) NOT NULL,
  `chatid` int(11) NOT NULL,
  `message` text NOT NULL,
  `files` text NOT NULL,
  `datemessage` varchar(50) NOT NULL,
  `statm` int(11) NOT NULL,
  `delstat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentpost`
--

CREATE TABLE `commentpost` (
  `cp_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `acc_id` int(11) NOT NULL,
  `commentMess` text NOT NULL,
  `datecomment` varchar(50) NOT NULL,
  `cstat` int(11) NOT NULL,
  `delstat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentpostnotification`
--

CREATE TABLE `commentpostnotification` (
  `nid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `replayid` int(11) NOT NULL,
  `postcomment` text NOT NULL,
  `stat` int(11) NOT NULL,
  `datenotification` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `friendlist`
--

CREATE TABLE `friendlist` (
  `fid` int(11) NOT NULL,
  `accid` int(11) NOT NULL,
  `follower` int(11) NOT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `messnotification`
--

CREATE TABLE `messnotification` (
  `id` int(11) NOT NULL,
  `myid` int(11) NOT NULL,
  `replayid` int(11) NOT NULL,
  `stat` int(11) NOT NULL,
  `message` text NOT NULL,
  `files` text NOT NULL,
  `datemessage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `muted`
--

CREATE TABLE `muted` (
  `id` int(11) NOT NULL,
  `reportid` int(11) NOT NULL,
  `mutedid` int(11) NOT NULL,
  `datemuted` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `post_user`
--

CREATE TABLE `post_user` (
  `p_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `caption` text NOT NULL,
  `img_vid` text NOT NULL,
  `date_post` varchar(50) NOT NULL,
  `delstatus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `reactpost`
--

CREATE TABLE `reactpost` (
  `rpid` int(11) NOT NULL,
  `myid` int(11) NOT NULL,
  `postidreact` int(11) NOT NULL,
  `reactstat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `chatfriend`
--
ALTER TABLE `chatfriend`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentpost`
--
ALTER TABLE `commentpost`
  ADD PRIMARY KEY (`cp_id`);

--
-- Indexes for table `commentpostnotification`
--
ALTER TABLE `commentpostnotification`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `friendlist`
--
ALTER TABLE `friendlist`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `messnotification`
--
ALTER TABLE `messnotification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `muted`
--
ALTER TABLE `muted`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_user`
--
ALTER TABLE `post_user`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `reactpost`
--
ALTER TABLE `reactpost`
  ADD PRIMARY KEY (`rpid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chatfriend`
--
ALTER TABLE `chatfriend`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `commentpost`
--
ALTER TABLE `commentpost`
  MODIFY `cp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `commentpostnotification`
--
ALTER TABLE `commentpostnotification`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `friendlist`
--
ALTER TABLE `friendlist`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messnotification`
--
ALTER TABLE `messnotification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `muted`
--
ALTER TABLE `muted`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post_user`
--
ALTER TABLE `post_user`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reactpost`
--
ALTER TABLE `reactpost`
  MODIFY `rpid` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
