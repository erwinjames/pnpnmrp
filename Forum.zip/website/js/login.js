$(document).ready(function(){
	$('.signin').on('click',function(){
		var datas = new FormData();
		 datas.append('login',1);
		 datas.append('username',$('#input').val());
		 datas.append('password',$('#password').val());
		 	 $.ajax({
		        url: 'http://localhost/website/php/post.php',
		        type: 'POST',
		        data: datas,
		        contentType: false,
		        cache: false,
		        processData: false,
		        success: function (result) {
		        	if(result != 0){
		        		localStorage.setItem("sessionId",result);
		        		location.href = "Home.html";
		        	}else{
		        		alert('Incorrect username or password.');
		        	}
		        }
		    })
	})
	$('._register').on('click',function(){
		if($('#fname').val().length > 3  &&  $('#lname').val().length > 3){
			if($('#uname').val().length > 6  &&  $('#password2').val().length > 6){
				if($('.gender').val()!=''){
					var datas = new FormData();
					 datas.append('register',1);
					
					 datas.append('fname',$('#fname').val());
					 datas.append('lname',$('#lname').val());
					 datas.append('gender',$('.gender').val());
					 datas.append('username',$('#uname').val());
					 datas.append('password',$('#password2').val());
					 	 $.ajax({
					        url: 'http://localhost/website/php/post.php',
					        type: 'POST',
					        data: datas,
					        contentType: false,
					        cache: false,
					        processData: false,
					        success: function (result) {
					        	if(result==null){
					        		$('#uname').val('');
					        		alert('Username is already exists.');
					        	}else{
					        		localStorage.setItem("sessionId",result);
				        			location.href = "Home.html";
					        	}
					        }
					    })		
			 	}else{
			 		alert('select gender.');
			 	}
			}else{
				alert('username and password must be 6 or more length');
			}
		}else{
			alert('FirstName And LastName must be 3 or more length');
		} 
	});
});

if(localStorage.getItem("sessionId")){
    location.href ='Home.html';  
}
