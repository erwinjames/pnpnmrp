if (!localStorage.getItem("postPage") || !localStorage.getItem("sessionId")) {
    window.location.href = "Home.html";
}
var sessionId = localStorage.getItem("sessionId"),url = 'http://localhost/website/php/post.php' , latestPost = 0,ila = 0,selectid =0,__mute=0,__comment = 0,__reply =0 ;
console.log(sessionId)
var month = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],_date = new Date(),date=month[_date.getMonth()] +' '+_date.getDate()+' '+_date.getFullYear();
$(document).ready(function(){
	userImage()
	loadPeople();
	loadmuted();
	muteref();
	loadNewMuted();
	// refresPosthData();
	getPostLastId();
	loadPostCondition();
	countnewmessage();
	countnewcommentpost();
	loadNotificationPost();

	countpostpage();

	let _files2 = document.querySelector('.chatFile');
	let _prevImageContainer2 = document.querySelector('.imagePreviewChat');
	let _prevView = _prevImageContainer2.querySelector('._imgpreviewChat');
	let _prevVid2 = _prevImageContainer2.querySelector('._vidpreviewChat2');
	$('.hitchat').on('click',function(){
		$('.chatFile').click();
	})
	_files2.addEventListener('change',function(){
	let file = this.files[0];
		let existsExtension = [['gif'],['mp4'],['jpg'],['png']];
	let fileExtension =  file.name.substring(file.name.lastIndexOf('.')+1).toLowerCase();  
		if(file){
			for (var i = 0; i < existsExtension.length; i++) {
				if(existsExtension[i] == fileExtension){
					let reader = new FileReader();
					_prevView.style.display = "block";

					reader.addEventListener("load",function(){
							if(fileExtension == 'mp4'){
						_prevVid2.setAttribute("src",this.result);
						}else{
						_prevView.setAttribute("src",this.result);
						}
					});
					reader.readAsDataURL(file);
				}
			}

		}else{
		_prevVid2.setAttribute("src",'');
			_prevView.setAttribute("src",'');
			_prevView.style.display = null;
		}
	})

	$('.chatmessage').on('keydown',function(e){
		if (event.keyCode == 13) {
			var files = document.querySelector('.chatFile').files;
			chatFriendSentmessage(e.target.value,$(this).attr('chat-id'),files[0]);
		}
	});

	$('._mute').on('click',function(){
		if ($(this).attr('chtmute') != "null") {
			muted($(this).attr('chtmute'));
		}
		return false;

	});

	$('.top-area > .setting-area > li').on("click",function(){
		console.log($(this).attr('note'));
		$(this).siblings().children('div').removeClass('active');
		$(this).children('div').addClass('active');
		if($(this).attr('note') == 'messages'){
			messageNotification();
		}else if($(this).attr('note') == 'notification'){
			commentNotification();
		}else if($(this).attr('note') == 'home'){
			location.href = "Home.html";
		}else if($(this).attr('note')=='postpage'){
			postnewsfeed();
		}
		return false;
	})

	$('.csmile > span').on('click',function(){
		$(this).parent().siblings(".smilebunch").toggleClass("active");
	});
	$('.logout').on('click',function(){
		localStorage.clear();
		location.href = "login.html";
	})
	$('._timeline').on('click',function(){
		location.href = "timeline.html";
	})

});

function userImage(){
	var datas = new FormData();
	 datas.append('userimage',1);
	  datas.append('sessionId',sessionId)
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	$('.imageuser').attr('src',result);
	        	
	        }
	    })
}

function loadNotificationPost(){
	var datas = new FormData();
	 datas.append('noti',1);
	 datas.append('postid',localStorage.getItem("postPage"))
	 	 $.ajax({
	        url: 'http://localhost/website/php/noti.php',
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	loadappend(result);
	        	commentPostButton();
	        }
	    })
}

function loadPeople(){
	 var datas = new FormData();
	 datas.append('loadpeople',1);
	  datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	$('#people-list').append(result);
	        	loadPeopleButton();
	        }
	    })
}

function loadmuted(){
	 var datas = new FormData();
	 datas.append('mutedPeople',1);
	 datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	$('.followers').append(result)
				loadMuteButton();
	        }
	    })
}
function postnewsfeed(){
	var datas = new FormData();
	 datas.append('postnews',1);
	 datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
				if(result != ''){
					$('.postnewsfeed').html('');
					$('.postnewsfeed').append(result);
					loadNewNotification();
				}
				
	        }
	    })
}

// function refresPosthData(){
	
// 	var datas = new FormData();
// 	datas.append('ref',1);
// 	setInterval(refresh, 2000);
    
//     function refresh(){
        
// 	 	 $.ajax({
// 	        url: url,
// 	        type: 'POST',
// 	        data: datas,
// 	        contentType: false,
// 	        cache: false,
// 	        processData: false,
// 	        success: function (result) {
	        	
// 	        	if(result > latestPost){
// 	        		// latestPost = result;
// 	        		lastPost();
// 	    			newpost(result);
// 	        	}
// 	        }
// 	    })
//     }

// }

function messageNotification(){
	 var datas = new FormData();
	 datas.append('messageNotification',1);
	 datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
				if(result != ''){
					$('.message').html('');
		        	loadMessageNotificationAppend(result.items[0]);
					loadPeopleButton();	
				}
				
	        }
	    })
}

function countnewmessage(){
var datas = new FormData();
	datas.append('refmess',1);
	 datas.append('sessionId',sessionId);
	setInterval(refresh, 2000);
    
    function refresh(){
        
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	$('.countmessage').html(result == 0 ? '' : result);
	        }
	    })
    }	
}

function loadMessageNotificationAppend(result){
	$('.message').append(result);
}

function commentNotification(){
	 var datas = new FormData();
	 datas.append('commentNotification',1);
	 datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
				if(result != ''){
					$('.notifications').html('');
					// $('.notifications2').html('');
		        	loadNewNotificationAppend(result);
					loadNewNotification();	
				}
				
	        }
	    })
}

function countnewcommentpost(){
var datas = new FormData();
	datas.append('refnotification',1);
	 datas.append('sessionId',sessionId);
	setInterval(refresh, 2000);
    
    function refresh(){
        
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	$('.countnotification').html(result == 0 ? '' : result);
	        }
	    })
    }	
}
function countpostpage(){
var datas = new FormData();
	datas.append('repostnews',1);
	 datas.append('sessionId',sessionId);
	setInterval(refresh, 2000);
    
    function refresh(){
        
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	$('.countpostpage').html(result == 0 ? '' : result);
	        }
	    })
    }	
}

function updateNewnotification(postid,accid){
var datas = new FormData();
	 datas.append('updateNewCommentNotification',1);
	 datas.append('postid',postid);
	  datas.append('accid',accid);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	localStorage.setItem("postPage",postid);
				location.href = "notification.html";
	        }
	    })	
}


function loadNewNotificationAppend(result){
	$('.notifications').append(result);
	// $('.notifications').append(result2);
}



function getPostLastId(){
	 var datas = new FormData();
	 datas.append('getPostLastId',1);
		 	 $.ajax({
		        url: url,
		        type: 'POST',
		        data: datas,
		        contentType: false,
		        cache: false,
		        processData: false,
		        success: function (result) {

		        	__comment = result;
		        	console.log('----'+result)
		        }
		    })
}

function loadPostCondition(){

	var datas = new FormData();
		datas.append('loadPostcondition',1);
		setInterval(refresh, 800);
	    
	    function refresh(){
	        
		 	 $.ajax({
		        url: url,
		        type: 'POST',
		        data: datas,
		        contentType: false,
		        cache: false,
		        processData: false,
		        success: function (result) {
		        	if(result != ''){
			        	if(result.items[0]['cp_id'] > __comment){
			    			console.log('good')
			    			getPostLastId();
			    			loadCommentAppend(result.items[0]['cp_id'],result.items[0]['p_id']);
			        		
			        	}
			        }
		        }
		    })
	    }

}

function loadCommentAppend(cpid,pid){
	var datas = new FormData();
	datas.append('loadnewComment',1);
	datas.append('cpid',cpid);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	console.log('bad'+__comment);
	        	newcommentappend(pid,result);
	        }
	    })
}

function newcommentappend(pid,result){
	$('.newincomingcomment'+pid).append(result);
}

function heartReact(pid){
	 var datas = new FormData();
	 datas.append('heartreact',1);
	 datas.append('sessionId',sessionId);
	 datas.append('pid',pid);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	console.log(result);
	        }
	    })
}

function brokenReact(pid){
	 var datas = new FormData();
	 datas.append('brokenreact',1);
	 datas.append('sessionId',sessionId);
	 datas.append('pid',pid);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	      	console.log(result);
	        }
	    })
}


function loadappend(result){
	$('.user-post').append(result);
}

function selectFriend(friendid,name){

	var datas = new FormData();
		 datas.append('chatfriend',1);
		 datas.append('sessionId',sessionId);
		 datas.append('friendid',friendid);
		 	 $.ajax({
		        url: url,
		        type: 'POST',
		        data: datas,
		        contentType: false,
		        cache: false,
		        processData: false,
		        success: function (result) {
		        	if(result.items[0] != 'null-101'){
		        		if(result.muted[0] != 'null-808')
		        		{
		        			ila = result.id[0] == null ? 0 : result.id[0];
		        			$('._mute').attr('chtmute',friendid);
			        		$('.chatul').html('');
			        		$('.chat-box').addClass("show");
							$('.nameF').text(name);
							$('.chatmessage').attr('chat-id',friendid);
							selectid = friendid;
							loadNewMessage(result.items[0]);
							refreshChatmessage();
							updatestatmessagenotification();
							$('.chatul').animate({scrollTop:$('.chatul')[0].scrollHeight});
		        		}else{
		        			$('.close-mesage').click();
		        			alert('Your friend is muted.');

		        		}
		        	}else{
		        		$('.close-mesage').click();
		        		alert('This user is muted you for being not good friend.');
		        	}
		        }
		    })
}

function refreshChatmessage(){
	var datas = new FormData();
 	
	setInterval(refresh, 800);
    
    function refresh(){
	datas.append('refreshChatmessage',1);
    datas.append('friendid',selectid);
    datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	
	        	if(result > ila){
	        		ila = result;
	        		newmessagerecieved();
	        	}
	        }
	    })
    }
}

function newmessagerecieved() {
	
	var datas = new FormData();
	 datas.append('newmessage',1);
	 datas.append('friendid',selectid);
	 datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	$('.chatul').animate({scrollTop:$('.chatul')[0].scrollHeight});
	        	loadNewMessage(result);
	        }
	    })

}

function updatestatmessagenotification(){
var datas = new FormData();
	 datas.append('updateMessageNotification',1);
	 datas.append('friendid',selectid);
	 datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        }
	    })	
}

function loadNewMessage(result){
	$('.chatul').append(result);	
}

function chatFriendSentmessage(mess,friendid,files){
	var datas = new FormData();
		 datas.append('sentmessage',1);
		 datas.append('file',files);
		 datas.append('sessionId',sessionId);
		 datas.append('friendid',friendid);
		 datas.append('message',mess);
		 datas.append('datemessage',date);
		 	 $.ajax({
		        url: url,
		        type: 'POST',
		        data: datas,
		        contentType: false,
		        cache: false,
		        processData: false,
		        success: function (result) {
		        	if(result == 'null-101'){
		        		alert('This user is not your friend.');
		        	}else if(result == 'null-102'){
		        		alert('This user is no longer your friend list.');
		        	}
		        	updatestatmessagenotification();
		        	$('.chatmessage').val('');
		        	$('.chatFile').val('');
					$('._imgpreviewChat').attr('src','');
					$('._vidpreviewChat2').attr('src','');
		        }
		    })	
}

function commentPost(userId,postId,commentMess,datecomment){
	var datas = new FormData();
		 datas.append('postComment',1);
		 datas.append('userId',userId);
		 datas.append('postId',postId);
		 datas.append('commentMess',commentMess);
		 datas.append('datecomment',datecomment);
		 	 $.ajax({
		        url: url,
		        type: 'POST',
		        data: datas,
		        contentType: false,
		        cache: false,
		        processData: false,
		        success: function (result) {
		        	console.log(result);
		        	$('.newincomingcomment'+postId).animate({scrollTop:$('.newincomingcomment'+postId)[0].scrollHeight});
		        	$('.comments'+postId).val('');
		        }
		    })
}

function muted(ff) {
	var datas = new FormData();
		 datas.append('mutedfriend',1);
		 datas.append('sessionId',sessionId);
		 datas.append('friendid',ff);
		 	 $.ajax({
		        url: url,
		        type: 'POST',
		        data: datas,
		        contentType: false,
		        cache: false,
		        processData: false,
		        success: function (result) {
		        	$('.close-mesage').click();
		        }
		    })
}

function unmutedFriend(mutedid){
var datas = new FormData();
		 datas.append('unmutedfriend',1);
		 datas.append('sessionId',sessionId);
		 datas.append('mutedid',mutedid);
		 	 $.ajax({
		        url: url,
		        type: 'POST',
		        data: datas,
		        contentType: false,
		        cache: false,
		        processData: false,
		        success: function (result) {
					$('.mute'+mutedid).remove();
		        }
		    })
}

function muteref(){
	var datas = new FormData();
	 datas.append('muteref',1);
	 datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	__mute = result;
	        }
	    })
}

function loadNewMuted(){
	var datas = new FormData();
 	
	setInterval(refresh, 800);
    
    function refresh(){
	datas.append('newmuted',1);
    datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	
	        	if(result > __mute){
	        		console.log('909');
	        		__mute = result;
	        		loadRefMuted();
	        	}
	        }
	    })
    }
}

function loadRefMuted(){
	
	var datas = new FormData();

	datas.append('loadnewmuted',1);
    datas.append('sessionId',sessionId);
	 	 $.ajax({
	        url: url,
	        type: 'POST',
	        data: datas,
	        contentType: false,
	        cache: false,
	        processData: false,
	        success: function (result) {
	        	$('.followers').append(result)
	        	loadMuteButton();
	        }
	    })
    
}

function seeComentShow(thisid){
	document.querySelector('.newincomingcomment'+thisid).style.display = "block";
}

function loadNewNotification(){
	$('.comment-meta').on('click', function() {
		updateNewnotification($(this).attr('post-id'),$(this).attr('accid'));
		return false;
	});	

}

function loadPeopleButton(){
	$('.friendz-meta').on('click', function() {
		ila = 0;
		selectid =0;
		selectFriend($(this).attr('dataid'),$(this).attr('name'));
		return false;
	});	
}

function loadMuteButton(){
	$('.mutedperson').on('click',function(){
		console.log($(this).attr('mutedid'));
		unmutedFriend($(this).attr('mutedid'));
		return false;
	})
}

function commentPostButton(){
	document.querySelectorAll('.userComment').forEach(uc => uc.addEventListener('keydown',()=>{
		if (event.keyCode == 13) {

			
			var postId = uc.getAttribute('data-comment');
				
			if($('.comments'+postId).val() != ''){
				var userId = sessionId,
				commentMess = $('.comments'+postId).val(),
				datecomment = date;
				commentPost(userId,postId,commentMess,datecomment);	
				
			}else{
				 $('.comments'+postId).val('');
			}
			
			
		}
		return false;
	}));

	$('.seecomment').on('click',function(){
		seeComentShow($(this).attr('id-button'));
	});

	$('.clickheart').on('click',function(){
		heartReact($(this).attr('heart'));
		return false;
	});

	$('.clickbroken').on('click',function(){
		brokenReact($(this).attr('broke'));
		return false;
	});
$('.viewtimeline').on('click',function(){
	if($(this).attr('dataid')!=sessionId){
		localStorage.setItem("timelineID",$(this).attr('dataid'));
		location.href = "viewtimeline.html";
	}
		return false;
	});
	document.querySelectorAll('.add-smiles').forEach(as => as.addEventListener('click',()=>{
		 
		 if(as.getAttribute('closeopen') == "close"){
		 	as.setAttribute('closeopen','open');
		 	document.querySelector('.smile'+as.getAttribute('bounch')).style.display = "block";
		 	
		 }else{
		 	as.setAttribute('closeopen','close');
		 	document.querySelector('.smile'+as.getAttribute('bounch')).style.display = "none";
		 	
		 }
	    return	false;
	}));
	document.querySelectorAll('.selecticon').forEach(as => as.addEventListener('click',()=>{

		document.querySelector('.comments'+as.getAttribute('emoji')).html('<i class="em '+as.getAttribute('icons')+'"></i>');
		 
	    return	false;
	}));

}


