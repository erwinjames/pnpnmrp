<?php

	$conn = mysqli_connect('localhost','root','','socialnetwork');
    if(!$conn){die('Error:' .mysqli_error($conn));}
    $data = '';
    extract($_REQUEST);
    $array = array();

	if(isset($_REQUEST['latestIdPost'])){

		$sql = "SELECT * FROM post_user b ORDER BY b.p_id DESC LIMIT 1";
		$lip = mysqli_query($conn,$sql);

		echo mysqli_fetch_array($lip)['p_id'];
	}
	if(isset($_REQUEST['latestIdPost2'])){

		$sql = "SELECT * FROM post_user b WHERE b.u_id = '{$sessionId}' ORDER BY b.p_id DESC LIMIT 1";
		$lip = mysqli_query($conn,$sql);

		echo mysqli_fetch_array($lip)['p_id'];
	}

	if(isset($_REQUEST['loadPost'])){

		$sql = "SELECT * FROM account a JOIN post_user b ON b.u_id = a.a_id ORDER BY b.p_id DESC";
 		$resultLostPost = mysqli_query($conn,$sql);
		
		while($row = mysqli_fetch_array($resultLostPost)){
			if($row['delstatus'] ==0){
				$data .= '<div class="friend-info">
												<figure>
													<img src="'.$row['aimage'].'" alt="">
												</figure>
												<div class="friend-name">
													<ins><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$row['a_id'].'" >'.$row['fname'].'</a></ins>
													<span>published: '.$row['date_post'].'</span>
												</div>
							<div class="post-meta">';
					if($row['img_vid']!='' && strpos($row['img_vid'],'.jpg') != false || strpos($row['img_vid'],'.png') != false  || strpos($row['img_vid'],'.gif') != false){
						$data .= '<img src="'.$row['img_vid'].'">';
					}else if($row['img_vid'] != '' && strpos($row['img_vid'],'.mp4') != false){
						$data .= '<video src = "'.$row['img_vid'].'" controls type="video/mp4" style="width:100%;>';
					}		

						$data .= '<div class="description">
														
														<p>
															'.$row['caption'].'
														</p>
													</div>
												</div>
											</div>
											<div class="coment-area ">
								<div class="we-video-info">
								<ul>';
							$sqlchatcount = "SELECT count(a.p_id) FROM commentpost a WHERE a.p_id = '".$row['p_id']."' ";
								$resultchaatcount = mysqli_query($conn,$sqlchatcount);

															$data .= '<li>
																<span class="comment" data-toggle="tooltip" title="Comments">
																	<i class="fa fa-comments-o"></i>
																	<ins>'. mysqli_fetch_array($resultchaatcount)['count(a.p_id)']
																	.'</ins>
																</span>
															</li>';

															$sqlReact = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 1";
															$resultReact = mysqli_query($conn,$sqlReact);
															if(mysqli_num_rows($resultReact) != 0){
																	$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																			<span class="like" data-toggle="tooltip" title="like">
																			<i class="ti-heart"></i>
																				<ins>'.mysqli_fetch_array($resultReact)['count(reactstat)'].'</ins></span></li>';
															}else{

																$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																		<span class="like" data-toggle="tooltip" title="like">
																			<i class="ti-heart"></i>
																			<ins></ins>
																		</span>
																	</li>';
															}

															$sqlReact2 = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 2";
															$resultReact2 = mysqli_query($conn,$sqlReact2);
															if(mysqli_num_rows($resultReact2) != 0){
																	$data .= '<li class="clickbroken" broke="'.$row['p_id'].'">
																			<span class="dislike" data-toggle="tooltip" title="dislike">
																				<i class="ti-heart-broken"></i>
																				<ins>'.mysqli_fetch_array($resultReact2)['count(reactstat)'].'</ins></span></li>';
															}else{

																$data .= '	<li class="clickbroken" broke="'.$row['p_id'].'">
																		<span class="dislike" data-toggle="tooltip" title="dislike">
																			<i class="ti-heart-broken"></i>
																			<ins></ins>
																		</span>
																	</li>';
															}
														$data .= '</ul>
													</div>
											<span>Comments</span>
											<hr>
											<ul class="we-comet newincomingcomment'.$row['p_id'].'" >';

				$sqlComment = "SELECT * FROM commentpost a JOIN account b ON a.acc_id = b.a_id WHERE a.p_id ='".$row['p_id']."' ORDER BY a.cp_id ASC ";
				$resultComment = mysqli_query($conn,$sqlComment);

				while($rowcomment = mysqli_fetch_array($resultComment)){
					$data .= '<li>
														<div class="comet-avatar">
															<img src="'.$rowcomment['aimage'].'" alt="">
														</div>
														<div class="we-comment">
															<div class="coment-head">
																<h5><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowcomment['a_id'].'">'.$rowcomment['fname'].'</a></h5>
																<span>'.$rowcomment['datecomment'].'</span>
															</div>
															<p>'.$rowcomment['commentMess'].'</p>
														</div>
													</li>';
					}
					$data .= '</ul></div><div class="form">
														 <textarea placeholder="Post your comment" class="comments'.$row['p_id'].'  txt userComment"  data-comment="'.$row['p_id'].'"></textarea>
															<div class="add-smiles" bounch='.$row['p_id'].' closeopen = "close">
																<span class="em em-expressionless" title="add icon"></span>
															</div>
															<div class="smiles-bunch smile'.$row['p_id'].'">
																<i class="em em---1 selecticon" emoji='.$row['p_id'].' icons="em---1"></i>
																<i class="em em-smiley selecticon" emoji='.$row['p_id'].'  icons="em-smiley"></i>
																<i class="em em-anguished selecticon" emoji='.$row['p_id'].'  icons="em-anguished"></i>
																<i class="em em-laughing selecticon" emoji='.$row['p_id'].'  icons="em-laughing"></i>
																<i class="em em-angry selecticon" emoji='.$row['p_id'].'  icons="em-angry"></i>
																<i class="em em-astonished selecticon" emoji='.$row['p_id'].'  icons="em-astonished"></i>
																<i class="em em-blush selecticon" emoji='.$row['p_id'].'  icons="em-blush"></i>
																<i class="em em-disappointed selecticon" emoji='.$row['p_id'].'  icons="em-disappointed"></i>
																<i class="em em-worried selecticon" emoji='.$row['p_id'].'  icons="em-worried"></i>
																<i class="em em-kissing_heart selecticon" emoji='.$row['p_id'].'  icons="em-kissing_heart"></i>
																<i class="em em-rage selecticon" emoji='.$row['p_id'].' icons="em-rage"></i>
																<i class="em em-stuck_out_tongue selecticon" emoji='.$row['p_id'].'  icons="em-stuck_out_tongue"></i>
															</div>
														
													
														</div><hr><br/><br/>';
			}
		}	

		echo $data;
	}

	if(isset($_REQUEST['getPostLastId'])){
		$sql = "SELECT * FROM commentpost ORDER BY cp_id DESC LIMIT 1";
		$res = mysqli_query($conn,$sql);

		echo mysqli_fetch_array($res)['cp_id'];
	}

	if(isset($_REQUEST['loadPostcondition'])){
		$resultarray2 = array();

		$sql2 = "SELECT * FROM commentpost ORDER BY cp_id DESC LIMIT 1";
		$res2 = mysqli_query($conn,$sql2);

		if(mysqli_num_rows($res2) != 0){
			while($row=mysqli_fetch_array($res2)){
				$resultarray2['items'][] = $row;
			}	
		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		
		echo json_encode($resultarray2);
		}
	}

	if(isset($_REQUEST['loadnewComment'])){

		$sqlComment2 = "SELECT * FROM commentpost a JOIN account b ON a.acc_id = b.a_id WHERE a.cp_id = '{$cpid}' ORDER BY a.cp_id DESC LIMIT 1";
		$resultComment2 = mysqli_query($conn,$sqlComment2);
		if(mysqli_num_rows($resultComment2) !=0){

			while($rowcomment = mysqli_fetch_array($resultComment2)){
				$data .= '<li>
								<div class="comet-avatar">
									<img src="'.$rowcomment['aimage'].'" alt="">
								</div>
									<div class="we-comment">
										<div class="coment-head">
											<h5><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowcomment['a_id'].'">'.$rowcomment['fname'].'</a></h5>
											<span>'.$rowcomment['datecomment'].'</span>
										</div>
									<p>'.$rowcomment['commentMess'].'</p>
															
								</div>
						</li>';
			}	
		}
		echo $data;
	}

	if(isset($_REQUEST['ref'])){

		$sql = "SELECT * FROM post_user b ORDER BY b.p_id DESC LIMIT 1";
		$refpost = mysqli_query($conn,$sql);

		echo mysqli_fetch_array($refpost)['p_id'];

	}
if(isset($_REQUEST['ref2'])){

		$sql = "SELECT * FROM post_user b WHERE b.u_id = '{$sessionId}' ORDER BY b.p_id DESC LIMIT 1";
		$refpost = mysqli_query($conn,$sql);

		echo mysqli_fetch_array($refpost)['p_id'];

	}

	if(isset($_REQUEST['newpost'])){

		$sql = "SELECT * FROM account a JOIN post_user b ON b.u_id = a.a_id WHERE b.p_id = '{$newppostid}' ORDER BY b.p_id DESC LIMIT 1";
 		$resultLostPost = mysqli_query($conn,$sql);
		
		while($row = mysqli_fetch_array($resultLostPost)){
			if($row['delstatus'] == 0){
				$data .= '<div class="friend-info">
												<figure>
													<img src="'.$row['aimage'].'" alt="">
												</figure>
												<div class="friend-name">
													<ins><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$row['a_id'].'">'.$row['fname'].'</a></ins>
													<span>published: '.$row['date_post'].'</span>
												</div>
							<div class="post-meta">';
					if($row['img_vid'] != '' && strpos($row['img_vid'],'.jpg') != false || strpos($row['img_vid'],'.png') != false  || strpos($row['img_vid'],'.gif') != false){
						$data .= '<img src="'.$row['img_vid'].'">';
					}else if ($row['img_vid'] != '' && strpos($row['img_vid'],'.mp4') != false){
						$data .= '<video src = "'.$row['img_vid'].'" controls type="video/mp4" style="width:100%;>';
					}		

						$data .= '<div class="description">
														
														<p>
															'.$row['caption'].'
														</p>
													</div>
												</div>
											</div>
											<div class="coment-area ">
								<div class="we-video-info">
								<ul>';
							$sqlchatcount = "SELECT count(a.p_id) FROM commentpost a WHERE a.p_id = '".$row['p_id']."' ";
								$resultchaatcount = mysqli_query($conn,$sqlchatcount);

															$data .= '<li>
																<span class="comment" data-toggle="tooltip" title="Comments">
																	<i class="fa fa-comments-o"></i>
																	<ins>'. mysqli_fetch_array($resultchaatcount)['count(a.p_id)']
																	.'</ins>
																</span>
															</li>';

															$sqlReact = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 1";
															$resultReact = mysqli_query($conn,$sqlReact);
															if(mysqli_num_rows($resultReact) != 0){
																	$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																			<span class="like" data-toggle="tooltip" title="like">
																			<i class="ti-heart"></i>
																				<ins>'.mysqli_fetch_array($resultReact)['count(reactstat)'].'</ins></span></li>';
															}else{

																$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																		<span class="like" data-toggle="tooltip" title="like">
																			<i class="ti-heart"></i>
																			<ins></ins>
																		</span>
																	</li>';
															}

															$sqlReact2 = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 2";
															$resultReact2 = mysqli_query($conn,$sqlReact2);
															if(mysqli_num_rows($resultReact2) != 0){
																	$data .= '<li class="clickbroken" broke="'.$row['p_id'].'">
																			<span class="dislike" data-toggle="tooltip" title="dislike">
																				<i class="ti-heart-broken"></i>
																				<ins>'.mysqli_fetch_array($resultReact2)['count(reactstat)'].'</ins></span></li>';
															}else{

																$data .= '	<li class="clickbroken" broke="'.$row['p_id'].'">
																		<span class="dislike" data-toggle="tooltip" title="dislike">
																			<i class="ti-heart-broken"></i>
																			<ins></ins>
																		</span>
																	</li>';
															}
														$data .= '</ul>
													</div>
											<span>Comments</span>
											<hr>
											<ul class="we-comet newincomingcomment'.$row['p_id'].'" >';

				$sqlComment = "SELECT * FROM commentpost a JOIN account b ON a.acc_id = b.a_id WHERE a.p_id ='".$row['p_id']."' ORDER BY a.cp_id ASC ";
				$resultComment = mysqli_query($conn,$sqlComment);

				while($rowcomment = mysqli_fetch_array($resultComment)){
					$data .= '<li>
														<div class="comet-avatar">
															<img src="'.$rowcomment['aimage'].'" alt="">
														</div>
														<div class="we-comment">
															<div class="coment-head">
																<h5><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowcomment['a_id'].'">'.$rowcomment['fname'].'</a></h5>
																<span>'.$rowcomment['datecomment'].'</span>
															</div>
															<p>'.$rowcomment['commentMess'].'</p>
														</div>
													</li>';
					}
					$data .= '</ul></div><div class="form">
														 <textarea placeholder="Post your comment" class="comments'.$row['p_id'].'  txt userComment"  data-comment="'.$row['p_id'].'"></textarea>
															<div class="add-smiles" bounch='.$row['p_id'].' closeopen = "close">
																<span class="em em-expressionless" title="add icon"></span>
															</div>
															<div class="smiles-bunch smile'.$row['p_id'].'">
																<i class="em em---1 selecticon" emoji='.$row['p_id'].' icons="em---1"></i>
																<i class="em em-smiley selecticon" emoji='.$row['p_id'].'  icons="em-smiley"></i>
																<i class="em em-anguished selecticon" emoji='.$row['p_id'].'  icons="em-anguished"></i>
																<i class="em em-laughing selecticon" emoji='.$row['p_id'].'  icons="em-laughing"></i>
																<i class="em em-angry selecticon" emoji='.$row['p_id'].'  icons="em-angry"></i>
																<i class="em em-astonished selecticon" emoji='.$row['p_id'].'  icons="em-astonished"></i>
																<i class="em em-blush selecticon" emoji='.$row['p_id'].'  icons="em-blush"></i>
																<i class="em em-disappointed selecticon" emoji='.$row['p_id'].'  icons="em-disappointed"></i>
																<i class="em em-worried selecticon" emoji='.$row['p_id'].'  icons="em-worried"></i>
																<i class="em em-kissing_heart selecticon" emoji='.$row['p_id'].'  icons="em-kissing_heart"></i>
																<i class="em em-rage selecticon" emoji='.$row['p_id'].' icons="em-rage"></i>
																<i class="em em-stuck_out_tongue selecticon" emoji='.$row['p_id'].'  icons="em-stuck_out_tongue"></i>
															</div>
														
													
														</div><hr><br/><br/>';
			}
		}

		echo $data;

	}
if(isset($_REQUEST['newpost2'])){

		$sql = "SELECT * FROM account a JOIN post_user b ON b.u_id = a.a_id WHERE b.p_id = '{$newppostid}' AND b.u_id = '{$sessionId}' ORDER BY b.p_id DESC LIMIT 1";
 		$resultLostPost = mysqli_query($conn,$sql);
		
		while($row = mysqli_fetch_array($resultLostPost)){
			if($row['delstatus'] == 0){
				$data .= '<div class="friend-info">
												<figure>
													<img src="'.$row['aimage'].'" alt="">
												</figure>
												<div class="friend-name">
													<ins><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$row['a_id'].'">'.$row['fname'].'</a></ins>
													<span>published: '.$row['date_post'].'</span>
												</div>
							<div class="post-meta">';
					if($row['img_vid'] != '' && strpos($row['img_vid'],'.jpg') != false || strpos($row['img_vid'],'.png') != false  || strpos($row['img_vid'],'.gif') != false){
						$data .= '<img src="'.$row['img_vid'].'">';
					}else if ($row['img_vid'] != '' && strpos($row['img_vid'],'.mp4') != false){
						$data .= '<video src = "'.$row['img_vid'].'" controls type="video/mp4" style="width:100%;>';
					}		

						$data .= '<div class="description">
														
														<p>
															'.$row['caption'].'
														</p>
													</div>
												</div>
											</div>
											<div class="coment-area ">
								<div class="we-video-info">
								<ul>';
							$sqlchatcount = "SELECT count(a.p_id) FROM commentpost a WHERE a.p_id = '".$row['p_id']."' ";
								$resultchaatcount = mysqli_query($conn,$sqlchatcount);

															$data .= '<li>
																<span class="comment" data-toggle="tooltip" title="Comments">
																	<i class="fa fa-comments-o"></i>
																	<ins>'. mysqli_fetch_array($resultchaatcount)['count(a.p_id)']
																	.'</ins>
																</span>
															</li>';

															$sqlReact = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 1";
															$resultReact = mysqli_query($conn,$sqlReact);
															if(mysqli_num_rows($resultReact) != 0){
																	$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																			<span class="like" data-toggle="tooltip" title="like">
																			<i class="ti-heart"></i>
																				<ins>'.mysqli_fetch_array($resultReact)['count(reactstat)'].'</ins></span></li>';
															}else{

																$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																		<span class="like" data-toggle="tooltip" title="like">
																			<i class="ti-heart"></i>
																			<ins></ins>
																		</span>
																	</li>';
															}

															$sqlReact2 = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 2";
															$resultReact2 = mysqli_query($conn,$sqlReact2);
															if(mysqli_num_rows($resultReact2) != 0){
																	$data .= '<li class="clickbroken" broke="'.$row['p_id'].'">
																			<span class="dislike" data-toggle="tooltip" title="dislike">
																				<i class="ti-heart-broken"></i>
																				<ins>'.mysqli_fetch_array($resultReact2)['count(reactstat)'].'</ins></span></li>';
															}else{

																$data .= '	<li class="clickbroken" broke="'.$row['p_id'].'">
																		<span class="dislike" data-toggle="tooltip" title="dislike">
																			<i class="ti-heart-broken"></i>
																			<ins></ins>
																		</span>
																	</li>';
															}
														$data .= '</ul>
													</div>
											<span>Comments</span>
											<hr>
											<ul class="we-comet newincomingcomment'.$row['p_id'].'" >';

				$sqlComment = "SELECT * FROM commentpost a JOIN account b ON a.acc_id = b.a_id WHERE a.p_id ='".$row['p_id']."' ORDER BY a.cp_id ASC ";
				$resultComment = mysqli_query($conn,$sqlComment);

				while($rowcomment = mysqli_fetch_array($resultComment)){
					$data .= '<li>
														<div class="comet-avatar">
															<img src="'.$rowcomment['aimage'].'" alt="">
														</div>
														<div class="we-comment">
															<div class="coment-head">
																<h5><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowcomment['a_id'].'">'.$rowcomment['fname'].'</a></h5>
																<span>'.$rowcomment['datecomment'].'</span>
															</div>
															<p>'.$rowcomment['commentMess'].'</p>
														</div>
													</li>';
					}
					$data .= '</ul></div><div class="form">
														 <textarea placeholder="Post your comment" class="comments'.$row['p_id'].'  txt userComment"  data-comment="'.$row['p_id'].'"></textarea>
															<div class="add-smiles" bounch='.$row['p_id'].' closeopen = "close">
																<span class="em em-expressionless" title="add icon"></span>
															</div>
															<div class="smiles-bunch smile'.$row['p_id'].'">
																<i class="em em---1 selecticon" emoji='.$row['p_id'].' icons="em---1"></i>
																<i class="em em-smiley selecticon" emoji='.$row['p_id'].'  icons="em-smiley"></i>
																<i class="em em-anguished selecticon" emoji='.$row['p_id'].'  icons="em-anguished"></i>
																<i class="em em-laughing selecticon" emoji='.$row['p_id'].'  icons="em-laughing"></i>
																<i class="em em-angry selecticon" emoji='.$row['p_id'].'  icons="em-angry"></i>
																<i class="em em-astonished selecticon" emoji='.$row['p_id'].'  icons="em-astonished"></i>
																<i class="em em-blush selecticon" emoji='.$row['p_id'].'  icons="em-blush"></i>
																<i class="em em-disappointed selecticon" emoji='.$row['p_id'].'  icons="em-disappointed"></i>
																<i class="em em-worried selecticon" emoji='.$row['p_id'].'  icons="em-worried"></i>
																<i class="em em-kissing_heart selecticon" emoji='.$row['p_id'].'  icons="em-kissing_heart"></i>
																<i class="em em-rage selecticon" emoji='.$row['p_id'].' icons="em-rage"></i>
																<i class="em em-stuck_out_tongue selecticon" emoji='.$row['p_id'].'  icons="em-stuck_out_tongue"></i>
															</div>
														
													
														</div><hr><br/><br/>';
			}
		}

		echo $data;

	}

	if(isset($_REQUEST['postComment'])){
		if($commentMess != ''){

			$sqlexist = "SELECT * FROM post_user WHERE p_id = '{$postId}' ";
			$rexists = mysqli_query($conn,$sqlexist);
			if(mysqli_num_rows($rexists)!=0){
				$sql = "INSERT INTO commentpost(p_id,acc_id,commentMess, datecomment, delstat) VALUES ('{$postId}','{$userId}','{$commentMess}','{$datecomment}',0)";
				$saveComent = mysqli_query($conn,$sql);

				$sql2 = "SELECT * FROM commentpostnotification WHERE cid = '{$postId}' AND replayid = '{$userId}' ";
				$s2 = mysqli_query($conn,$sql2);
					if(mysqli_num_rows($s2)!=0){

						$sql3 = "UPDATE `commentpostnotification` SET `stat`= 1 ,postcomment = '{$commentMess}' ,datenotification = '{$datecomment}' WHERE cid = '{$postId}' AND replayid = '{$userId}' ";
						$s3 = mysqli_query($conn,$sql3);
					}else{
						$sql4 = "INSERT INTO commentpostnotification(cid,replayid,postcomment,stat,datenotification) VALUES('{$postId}','{$userId}','{$commentMess}',1,'{$datecomment}')";
						$s4 = mysqli_query($conn,$sql4);
					}

					$sql5 = "UPDATE `commentpostnotification` SET `stat`= 0 ,datenotification = '{$datecomment}' WHERE cid = '{$postId}' AND replayid != '{$userId}' ";
					$s5 = mysqli_query($conn,$sql5); 
			}
		}
	}

	if(isset($_REQUEST['saveButtonPost'])){

		if(isset($_FILES['file']['name'])){
			$fileName = $_FILES['file']['name'];

			$location = '../imageVideo/'.$fileName;

			$fileExtenxsion = pathinfo($location,PATHINFO_EXTENSION);
			$fileExtenxsion = strtolower($fileExtenxsion);

			$validEx = array("jpg","png","jpeg","mp4","gif");

			if(in_array($fileExtenxsion, $validEx)){
				if(move_uploaded_file($_FILES['file']['tmp_name'], $location)){

					if($fileExtenxsion == "mp4"){
						$file = 'imageVideo/'.$fileName.'';
						$savePost = "INSERT INTO post_user (u_id,caption,img_vid,date_post,delstatus) values('{$idkoidmo}','{$caption}','{$file}','{$datePost}',0)";
												
												$resultSavePost = mysqli_query($conn,$savePost);
					}else {
						$file = 'imageVideo/'.$fileName.'';
						$savePost = "INSERT INTO post_user (u_id,caption,img_vid,date_post,delstatus) values('{$idkoidmo}','{$caption}','{$file}','{$datePost}',0)";
						
						$resultSavePost = mysqli_query($conn,$savePost);
					}
				}
			}
		}else{
			if($idkoidmo != '' && $caption != '' && $datePost !=''){
				$savePost = "INSERT INTO post_user (u_id,caption,date_post,delstatus) values('{$idkoidmo}','{$caption}','{$datePost}',0)";
				$resultSavePost = mysqli_query($conn,$savePost);
			}
		}
	}

	if(isset($_REQUEST['loadpeople'])){
		$sql = "SELECT * FROM account WHERE a_id != '{$sessionId}' ";
		$q = mysqli_query($conn,$sql);
			if(mysqli_num_rows($q)!=0){
				while ($r = mysqli_fetch_array($q)) {	
					$followerid = $r['a_id'];
					$sql2 = "SELECT * FROM friendlist a WHERE a.accid = '{$sessionId}' AND a.follower = '{$followerid}' OR a.accid = '{$followerid}' AND a.follower = '{$sessionId}'  ";
					$q2 = mysqli_query($conn,$sql2);
					$q3 = mysqli_query($conn,$sql2);
					if(mysqli_num_rows($q2) != 0){
						if(mysqli_fetch_array($q2)['stat'] == 1){
						$fid = mysqli_fetch_array($q3)['fid'];
						$data .= '<li>
									<figure href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'">
										<img src="'.$r['aimage'].'" alt="">
										<span class="status f-online"></span>
									</figure>
									<div class="friendz-meta" dataid = "'.$r['a_id'].'" name = "'.$r['fname'].'" ">
										<a>'.$r['fname'].'</a>
										<i>';
											if($r['status'] == 1){
												$data .= '<span>Onlines</span>';
											}else{
												$data .= '<span>Offline</span>';
											}									
										$data .= '</i>
									</div>
							</li>';
						}
					}
			}
			echo $data;
		}
	}

	if(isset($_REQUEST['chatfriend'])){
		
		$resultarray = array();

		$sqlMuted = "SELECT * FROM muted WHERE reportid = '{$friendid}' AND mutedid = '{$sessionId}' ";
		$resultmuted = mysqli_query($conn,$sqlMuted);
		if(mysqli_num_rows($resultmuted) == 0){
				$sql = "SELECT * FROM chatfriend WHERE myid = '{$sessionId}' AND chatid = '{$friendid}' OR myid = '{$friendid}' AND chatid = '{$sessionId}' ";
			$resultChat = mysqli_query($conn,$sql);

			if(mysqli_num_rows($resultChat) !=0 ){
				while ($rowchat = mysqli_fetch_array($resultChat)) {
								if($rowchat['myid'] == $sessionId && $rowchat['chatid'] == $friendid){
									
									$profile = "SELECT * FROM account WHERE a_id = '{$sessionId}' LIMIT 1";
									$resultprofile = mysqli_query($conn,$profile);

									$data .= '	<li class="you">
															<div class="notification-event">';
		if($rowchat['files']!='' && strpos($rowchat['files'],'.jpg') != false || strpos($rowchat['files'],'.png') != false  || strpos($rowchat['files'],'.gif') != false){
			$data .= '<img src="'.$rowchat['files'].'" style="height:200px;max-width:100%;">';
			}else if($rowchat['files'] != '' && strpos($rowchat['files'],'.mp4') != false){
						$data .= '<video src = "'.$rowchat['files'].'"  controls type="video/mp4" style="height:200px;max-width:100%;"></video>';
		}	

															
															$data .= $rowchat['message'] == '' ? '' : '<span class="chat-message-item">'.$rowchat['message'].'</span>';
															$data .= '<span class="notification-date"><time datetime="2004-07-24T18:18" class="entry-date updated">'.$rowchat['datemessage'].'</time></span>
															</div>
															<div class="chat-thumb">
																<img src="'.mysqli_fetch_array($resultprofile)['aimage'].'" alt="" href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$friendid.'">
															</div>
										
														</li>';
								}
								else if($rowchat['myid'] == $friendid && $rowchat['chatid'] == $sessionId){
									$profile = "SELECT * FROM account WHERE a_id = '{$friendid}' LIMIT 1";
									$resultprofile = mysqli_query($conn,$profile);
									$data .= '<li class="me">
										<div class="chat-thumb"><img src="'.mysqli_fetch_array($resultprofile)['aimage'].'" alt=""></div>
											<div class="notification-event">';

											if($rowchat['files']!='' && strpos($rowchat['files'],'.jpg') != false || strpos($rowchat['files'],'.png') != false  || strpos($rowchat['files'],'.gif') != false){
												$data .= '<img src="'.$rowchat['files'].'" style="height:200px;max-width:100%;">';
												}else if($rowchat['files'] != '' && strpos($rowchat['files'],'.mp4') != false){
															$data .= '<video src = "'.$rowchat['files'].'" controls type="video/mp4" style="height:200px;max-width:100%;"></video>';
											}	


												$data .= $rowchat['message'] == '' ? '' : '<span class="chat-message-item">'.$rowchat['message'].'</span>';
												$data .= '<span class="notification-date"><time datetime="2004-07-24T18:18" class="entry-date updated">'.$rowchat['datemessage'].'</time></span>
											</div>
									</li>';
								}
								
				}
			}
		}else{
			$data = 'null-101';
		}

		$sqlMuted2 = "SELECT * FROM muted WHERE reportid = '{$sessionId}' AND mutedid = '{$friendid}' ";
		$resultmuted2 = mysqli_query($conn,$sqlMuted2);

		if(mysqli_num_rows($resultmuted2) != 0){
			$resultarray['muted'][] = 'null-808';
		}else{
			$resultarray['muted'][] = 'null-202';
		}

		$lastdid = "SELECT COUNT(id) FROM chatfriend WHERE myid = '{$sessionId}' AND chatid = '{$friendid}' OR myid = '{$friendid}' AND chatid = '{$sessionId}' ORDER BY id DESC LIMIT 1 ";
		$resultlastid = mysqli_query($conn,$lastdid);

		$resultarray['items'][] = $data;
		$resultarray['id'][] = mysqli_fetch_array($resultlastid)['COUNT(id)'];

		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		
		echo json_encode($resultarray);

		// echo $data;
	}

	if(isset($_REQUEST['sentmessage'])){
		$sql2 = "SELECT * FROM friendlist a WHERE a.accid = '{$sessionId}' AND a.follower = '{$friendid}' OR a.accid = '{$friendid}' AND a.follower = '{$sessionId}'  ";
				$q2 = mysqli_query($conn,$sql2);
				if(mysqli_num_rows($q2) != 0){
					if(mysqli_fetch_array($q2)['stat'] == 1){
						if(isset($_FILES['file']['name'])){
							$fileName = $_FILES['file']['name'];

							$location = '../chatFileFolder/'.$fileName;

							$fileExtenxsion = pathinfo($location,PATHINFO_EXTENSION);
							$fileExtenxsion = strtolower($fileExtenxsion);

							$validEx = array("jpg","png","jpeg","mp4","gif");

							if(in_array($fileExtenxsion, $validEx)){
								if(move_uploaded_file($_FILES['file']['tmp_name'], $location)){
									$file = 'chatFileFolder/'.$fileName.'';
									$savePost = "INSERT INTO chatfriend (myid,chatid,message,files,datemessage) values('{$sessionId}','{$friendid}','{$message}','{$file}','{$datemessage}')";
									$resultSavePost = mysqli_query($conn,$savePost);

									$sqlmessnotification = "SELECT * FROM messnotification WHERE  myid = '{$sessionId}' AND replayid = '{$friendid}' ";
										$resultnotification = mysqli_query($conn,$sqlmessnotification);		
										if(mysqli_num_rows($resultnotification) != 0){

											$sql2 = "UPDATE `messnotification` SET stat = 0 , message = '{$message}',files = '{$file}',datemessage = '{$datemessage}',files = '{$file}' WHERE  myid = '{$sessionId}' AND replayid = '{$friendid}' ";
											$resultchat2 = mysqli_query($conn,$sql2);	


										}else{
										
											$sql3 = "INSERT INTO messnotification(myid,replayid,stat,message,files,datemessage) VALUES('{$sessionId}','{$friendid}',0,'{$message}','{$file}','{$datemessage}')";
											$resultchat3 = mysqli_query($conn,$sql3);	

										}
								}
							}
						}else{
						
							if($message != ''){
										$sql = "INSERT INTO chatfriend(myid,chatid,message,datemessage) VALUES('{$sessionId}','{$friendid}','{$message}','{$datemessage}')";
										$resultchat = mysqli_query($conn,$sql);

										$sqlmessnotification = "SELECT * FROM messnotification WHERE  myid = '{$sessionId}' AND replayid = '{$friendid}' ";
										$resultnotification = mysqli_query($conn,$sqlmessnotification);		
										if(mysqli_num_rows($resultnotification) != 0){

											$sql2 = "UPDATE `messnotification` SET stat = 0 , message = '{$message}',datemessage = '{$datemessage}' , files ='' WHERE  myid = '{$sessionId}' AND replayid = '{$friendid}' ";
											$resultchat2 = mysqli_query($conn,$sql2);	


										}else{
										
											$sql3 = "INSERT INTO messnotification(myid,replayid,stat,message,datemessage) VALUES('{$sessionId}','{$friendid}',0,'{$message}','{$datemessage}')";
											$resultchat3 = mysqli_query($conn,$sql3);	

										}
								}
						}
					
				}else{
					echo 'null-101';
				}
			}else{
				echo 'null-102';
			}
	}

	if(isset($_REQUEST['mutedPeople'])){
		$sqlmuted = "SELECT * FROM muted WHERE reportid = '{$sessionId}'";
		$resultmuted = mysqli_query($conn,$sqlmuted);
		
		while($rowmuted = mysqli_fetch_array($resultmuted)){
			$acc = "SELECT * FROM account WHERE a_id = '".$rowmuted['mutedid']."' ";
			$accmuted = mysqli_query($conn,$acc);
			while($rowacc = mysqli_fetch_array($accmuted)){
				$data .= '<li class="mu mute'.$rowacc['a_id'].'" mutedid = '.$rowacc['a_id'].'>
								<figure><img src="'.$rowacc['aimage'].'" alt=""></figure>
								<div class="friend-meta">
									<h4><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowacc['a_id'].'">'.$rowacc['fname'].'</a></h4>
									<span class="mutedperson" mutedid = '.$rowacc['a_id'].'>Unmuted</span>
								</div>
						</li>';
				
			}
		}
		echo $data;
	}

	if(isset($_REQUEST['muteref'])){
		$sqlmuted = "SELECT * FROM muted WHERE reportid = '{$sessionId}' ORDER BY id DESC LIMIT 1";
		$resultmuted = mysqli_query($conn,$sqlmuted);

		echo mysqli_fetch_array($resultmuted)['id'];
	}

	if(isset($_REQUEST['newmuted'])){

		$sqlmuted = "SELECT * FROM muted WHERE reportid = '{$sessionId}' ORDER BY id DESC LIMIT 1";
		$resultmuted = mysqli_query($conn,$sqlmuted);

		echo mysqli_fetch_array($resultmuted)['id'];
	}

	if(isset($_REQUEST['loadnewmuted'])){
		$sqlmuted = "SELECT * FROM muted WHERE reportid = '{$sessionId}' ORDER BY id DESC LIMIT 1";
		$resultmuted = mysqli_query($conn,$sqlmuted);
		
		while($rowmuted = mysqli_fetch_array($resultmuted)){
			$acc = "SELECT * FROM account WHERE a_id = '".$rowmuted['mutedid']."' ";
			$accmuted = mysqli_query($conn,$acc);
			while($rowacc = mysqli_fetch_array($accmuted)){
				$data .= '<li class="mu mute'.$rowacc['a_id'].'" mutedid = '.$rowacc['a_id'].'>
								<figure><img src="'.$rowacc['aimage'].'" alt=""></figure>
								<div class="friend-meta">
									<h4><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowacc['a_id'].'">'.$rowacc['fname'].'</a></h4>
									<span class="mutedperson" mutedid = '.$rowacc['a_id'].'>Unmuted</span>
								</div>
						</li>';
				
			}
		}
		echo $data;
	}

	if(isset($_REQUEST['mutedfriend'])){
		$sqlmuted = "INSERT INTO muted(reportid,mutedid) VALUES('{$sessionId}','{$friendid}')";
		$resultmuted = mysqli_query($conn,$sqlmuted);
	}

	if(isset($_REQUEST['unmutedfriend'])){
		$sqlmuted = "DELETE FROM `muted` WHERE reportid = '{$sessionId}' AND mutedid = '{$mutedid}' ";
		$resultmuted = mysqli_query($conn,$sqlmuted);
	}

	if(isset($_REQUEST['heartreact'])){
		$sqlreact = "SELECT * FROM reactpost b WHERE b.myid = '{$sessionId}' AND b.postidreact = '{$pid}'";
		$result = mysqli_query($conn,$sqlreact);

		if(mysqli_num_rows($result) != 0){
			$id = mysqli_fetch_array($result)['rpid'];
				$updated = "UPDATE `reactpost` SET reactstat = 1 WHERE rpid = '{$id}' ";  
				$resultinsert = mysqli_query($conn,$updated);
		}else{

			$insert = "INSERT INTO reactpost(myid,postidreact,reactstat) VALUES('{$sessionId}','{$pid}',1)";
			$resultinsert = mysqli_query($conn,$insert);
		}

	}
	if(isset($_REQUEST['brokenreact'])){
		$sqlreact = "SELECT * FROM reactpost b WHERE b.myid = '{$sessionId}' AND b.postidreact = '{$pid}'";
		$result = mysqli_query($conn,$sqlreact);

		if(mysqli_num_rows($result) != 0){
			$id = mysqli_fetch_array($result)['rpid'];
				$updated = "UPDATE `reactpost` SET reactstat = 2 WHERE rpid = '{$id}' ";  
				$resultinsert = mysqli_query($conn,$updated);
		}else{

			$insert = "INSERT INTO reactpost(myid,postidreact,reactstat) VALUES('{$sessionId}','{$pid}',2)";
			$resultinsert = mysqli_query($conn,$insert);
		}

	}

	if(isset($_REQUEST['refreshChatmessage'])){
		$lastdid = "SELECT COUNT(id) FROM chatfriend WHERE myid = '{$sessionId}' AND chatid = '{$friendid}' OR myid = '{$friendid}' AND chatid = '{$sessionId}' ORDER BY id DESC LIMIT 1 ";
		$resultlastid = mysqli_query($conn,$lastdid);
		
		echo mysqli_fetch_array($resultlastid)['COUNT(id)'];
	}	

	if(isset($_REQUEST['newmessage'])){
		$lastdid2 = "SELECT * FROM chatfriend WHERE myid = '{$sessionId}' AND chatid = '{$friendid}' OR myid = '{$friendid}' AND chatid = '{$sessionId}' ORDER BY id DESC LIMIT 1 ";
		$resultlastid2 = mysqli_query($conn,$lastdid2);	

			while ($rowchat = mysqli_fetch_array($resultlastid2)) {
								if($rowchat['myid'] == $sessionId && $rowchat['chatid'] == $friendid){
									
									$profile = "SELECT * FROM account WHERE a_id = '{$sessionId}' LIMIT 1";
									$resultprofile = mysqli_query($conn,$profile);

									$data .= '	<li class="you">
															<div class="notification-event">';
															if($rowchat['files']!='' && strpos($rowchat['files'],'.jpg') != false || strpos($rowchat['files'],'.png') != false  || strpos($rowchat['files'],'.gif') != false){
			$data .= '<img src="'.$rowchat['files'].'" style="height:200px;max-width:100%;">';
			}else if($rowchat['files'] != '' && strpos($rowchat['files'],'.mp4') != false){
						$data .= '<video src = "'.$rowchat['files'].'" controls type="video/mp4" style="height:200px;max-width:100%;"></video>';
		}	
																
																$data .= $rowchat['message'] == '' ? '' : '<span class="chat-message-item">'.$rowchat['message'].'</span>';
																$data .= '<span class="notification-date"><time datetime="2004-07-24T18:18" class="entry-date updated">'.$rowchat['datemessage'].'</time></span>
															</div>
															<div class="chat-thumb">
															<img src="'.mysqli_fetch_array($resultprofile)['aimage'].'" alt="" href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$friendid.'">
															</div>
										
														</li>';
								}
								else if($rowchat['myid'] == $friendid && $rowchat['chatid'] == $sessionId){
									$profile = "SELECT * FROM account WHERE a_id = '{$friendid}' LIMIT 1";
									$resultprofile = mysqli_query($conn,$profile);
									$data .= '<li class="me">
										<div class="chat-thumb"><img src="'.mysqli_fetch_array($resultprofile)['aimage'].'" alt=""></div>
											<div class="notification-event">';
											if($rowchat['files']!='' && strpos($rowchat['files'],'.jpg') != false || strpos($rowchat['files'],'.png') != false  || strpos($rowchat['files'],'.gif') != false){
			$data .= '<img src="'.$rowchat['files'].'" style="height:200px;max-width:100%;">';
			}else if($rowchat['files'] != '' && strpos($rowchat['files'],'.mp4') != false){
						$data .= '<video src = "'.$rowchat['files'].'" controls type="video/mp4" style="height:200px;max-width:100%;"></video>';
		}	
												$data .= $rowchat['message'] == '' ? '' : '<span class="chat-message-item">'.$rowchat['message'].'</span>';
												$data .= '<span class="notification-date"><time datetime="2004-07-24T18:18" class="entry-date updated">'.$rowchat['datemessage'].'</time></span>
											</div>
									</li>';
								}
								
				}

		echo $data;
	}

	if(isset($_REQUEST['messageNotification'])){

		$resultarray2 = array();
		$sql = "SELECT * FROM messnotification a JOIN account b ON a.myid = b.a_id WHERE a.replayid = '{$sessionId}' AND a.myid != '{$sessionId}' ";
		$resultmessnotification = mysqli_query($conn,$sql);	
		if(mysqli_num_rows($resultmessnotification) != 0 ){
			while ($row = mysqli_fetch_array($resultmessnotification)) {
				if($row['stat'] == 0){
					$data .= '<li class="friendz-meta" dataid="'.$row['myid'].'" name="'.$row['fname'].'" >
									<a href="notifications.html" title="">
										<img src="'.$row['aimage'].'" alt="">
										<div class="mesg-meta">
											<h6>'.$row['fname'].'</h6>';
											if($row['files']!='' && strpos($row['files'],'.jpg') != false || strpos($row['files'],'.png') != false  || strpos($row['files'],'.gif') != false){
			$data .= '<img src="'.$row['files'].'">';
			}else if($row['files'] != '' && strpos($row['files'],'.mp4') != false){
						$data .= '<video src = "'.$row['files'].'" style="max-width:100%; height:100px;" controls type="video/mp4" ></video>';
		}	
											$data .= $row['message'] == '' ? '' : '<span>'.$row['message'].'</span>';
											$data .= '<i>'.$row['datemessage'].'</i>
										</div>
									</a>
									<span class="tag green">New</span>
								</li>';
				}else{
					$data .= '<li class="friendz-meta" dataid="'.$row['myid'].'" name="'.$row['fname'].'" >
									<a href="notifications.html" title="">
										<img src="'.$row['aimage'].'" alt="">
										<div class="mesg-meta">
											<h6>'.$row['fname'].'</h6>';
											if($row['files']!='' && strpos($row['files'],'.jpg') != false || strpos($row['files'],'.png') != false  || strpos($row['files'],'.gif') != false){
			$data .= '<img src="'.$row['files'].'" >';
			}else if($row['files'] != '' && strpos($row['files'],'.mp4') != false){
						$data .= '<video src = "'.$row['files'].'" style="max-width:100%; height:100px;" controls type="video/mp4" ></video>';
		}	
											$data .= $row['message'] == '' ? '' : '<span>'.$row['message'].'</span>';
											$data .='<i>'.$row['datemessage'].'</i>
										</div>
									</a>
									<span class="tag red">old</span>
								</li>';
				}
			}
			$resultarray2['items'][] = $data;
		}

		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		
		echo json_encode($resultarray2);
	}

	if(isset($_REQUEST['refmess'])){
		$sql = "SELECT COUNT(id) FROM messnotification a JOIN account b ON a.myid = b.a_id WHERE a.replayid = '{$sessionId}' AND a.myid != '{$sessionId}' AND a.stat = 0";
		$resultmessnotification = mysqli_query($conn,$sql);	
		echo mysqli_fetch_array($resultmessnotification)['COUNT(id)'];
	}

	if(isset($_REQUEST['updateMessageNotification'])){
		$sql2 = "UPDATE `messnotification` SET stat = 1 WHERE  myid = '{$friendid}' AND replayid = '{$sessionId}' ";
		$resultchat2 = mysqli_query($conn,$sql2);	

	}

	if(isset($_REQUEST['commentNotification'])){
		
		$sql = "SELECT * FROM commentpost WHERE acc_id = '{$sessionId}' GROUP BY p_id ";
		$q = mysqli_query($conn,$sql);	
		if(mysqli_num_rows($q)!=0){
				while($r = mysqli_fetch_array($q)){
					$pid = $r['p_id'];
					$sql2 = "SELECT * FROM commentpostnotification a  JOIN account b ON a.replayid = b.a_id JOIN post_user c ON a.cid = c.p_id WHERE a.cid = '{$pid}' AND a.replayid != '{$sessionId}' ";
					$q2 = mysqli_query($conn,$sql2);
						while($r2 = mysqli_fetch_array($q2)){
							if($r2['stat'] == 1){
								$data .= '<li class="comment-meta" dataid ="'.$r2['p_id'].'" post-id = "'.$r2['p_id'].'">
									<a href="notification.html">
										<img src="'.$r2['aimage'].'" alt="">
										<div class="mesg-meta">
											<h6>'.$r2['fname'].'</h6>
											<span>'.$r2['postcomment'].'</span>';
											
											if($r2['img_vid']!='' || strpos($r2['img_vid'],'.jpg') != false || strpos($r2['img_vid'],'.png') != false  || strpos($r2['img_vid'],'.gif') != false){
												$data .= '<img src="'.$r2['img_vid'].'" style="height:40px;">';
											}else if($r2['img_vid'] != '' || strpos($r2['img_vid'],'.mp4') != false){
												$data .= '<video src = "'.$r2['img_vid'].'" type="video/mp4" style="height:20px;width:20px">';
											}		

											$data .= '<br/>'.$r2['caption'] == '' ? '' :  '<i>comment this post : <span>'.$r2['caption'].'</span></i><br/>'.'<i>'.$r2['datenotification'].'</i>
										</div>
									</a>
							</li>';
							}
						}
				}
				echo $data;
		}

	}

	if(isset($_REQUEST['refnotification'])){
		$sql = "SELECT * FROM commentpost WHERE acc_id = '{$sessionId}' GROUP BY p_id ";
				$q = mysqli_query($conn,$sql);	
				if(mysqli_num_rows($q)!=0){
						$a = 0;
						while($r = mysqli_fetch_array($q)){
							$pid = $r['p_id'];
							
							$sql2 = "SELECT count(*) FROM commentpostnotification a  JOIN account b ON a.replayid = b.a_id JOIN post_user c ON a.cid = c.p_id WHERE a.cid = '{$pid}' AND a.replayid != '{$sessionId}' AND a.stat = 1";
							$q2 = mysqli_query($conn,$sql2);
								$a +=  mysqli_fetch_array($q2)['count(*)'];
								$data = $a;
						}
						echo $data;
				}					
	}

	if(isset($_REQUEST['updateNewCommentNotification'])){

		$sql3 = "UPDATE `commentpostnotification` SET `stat`= 1 ,postcomment = '{$commentMess}' ,datenotification = '{$datecomment}' WHERE cid = '{$postid}' AND replayid = '{$sessionId}' ";
		$s3 = mysqli_query($conn,$sql3); 
		
		$sql5 = "UPDATE `commentpostnotification` SET `stat`= 0 ,datenotification = '{$datecomment}' WHERE cid = '{$postid}' AND replayid != '{$sessionId}' ";
				$s5 = mysqli_query($conn,$sql5); 

	}

	if(isset($_REQUEST['login'])){

		$sqllogin = "SELECT * FROM account WHERE username = '{$username}' AND password = '{$password}' LIMIT 1";
		$result = mysqli_query($conn,$sqllogin);
		if(mysqli_num_rows($result) !=0){
			$data = mysqli_fetch_array($result)['a_id'];
		}else{
			$data = 0;
		}
		echo $data;

	}

	if(isset($_REQUEST['userimage'])){
		$sqllogin = "SELECT * FROM account WHERE a_id = '{$sessionId}'  LIMIT 1";
		$result = mysqli_query($conn,$sqllogin);
		echo ''.mysqli_fetch_array($result)['aimage'].'';
		
	}

	if(isset($_REQUEST['backgroundImage'])){
		$sqllogin = "SELECT * FROM account WHERE a_id = '{$sessionId}'  LIMIT 1";
		$result = mysqli_query($conn,$sqllogin);
		echo ''.mysqli_fetch_array($result)['bimage'].'';
		
	}

	if(isset($_REQUEST['loadPost2'])){

		$sql = "SELECT * FROM account a JOIN post_user b ON b.u_id = a.a_id WHERE b.u_id = '{$sessionId}' ORDER BY b.p_id DESC";
 		$resultLostPost = mysqli_query($conn,$sql);
		if(mysqli_num_rows($resultLostPost)!=0){
			while($row = mysqli_fetch_array($resultLostPost)){
				if($row['delstatus'] == 0){
					$data .= '<div class="friend-info">
													<figure>
														<img src="'.$row['aimage'].'" alt="">
													</figure>
													<div class="friend-name">
														<ins><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$row['a_id'].'">'.$row['fname'].'</a></ins>
														<span>published: '.$row['date_post'].'</span>

													</div>
								<div class="post-meta">';
						if($row['img_vid']!='' && strpos($row['img_vid'],'.jpg') != false || strpos($row['img_vid'],'.png') != false  || strpos($row['img_vid'],'.gif') != false){
							$data .= '<img src="'.$row['img_vid'].'">';
						}else if($row['img_vid'] != '' && strpos($row['img_vid'],'.mp4') != false){
							$data .= '<video src = "'.$row['img_vid'].'" controls type="video/mp4" style="width:100%;>';
						}		

							$data .= '<div class="description">
															
															<p>
																'.$row['caption'].'
															</p>
														</div>
													</div>
												</div>
												<div class="coment-area ">
									<div class="we-video-info">
									<ul>';
								$sqlchatcount = "SELECT count(a.p_id) FROM commentpost a WHERE a.p_id = '".$row['p_id']."' ";
									$resultchaatcount = mysqli_query($conn,$sqlchatcount);

																$data .= '<li>
																	<span class="comment" data-toggle="tooltip" title="Comments">
																		<i class="fa fa-comments-o"></i>
																		<ins>'. mysqli_fetch_array($resultchaatcount)['count(a.p_id)']
																		.'</ins>
																	</span>
																</li>';

																$sqlReact = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 1";
																$resultReact = mysqli_query($conn,$sqlReact);
																if(mysqli_num_rows($resultReact) != 0){
																		$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																				<span class="like" data-toggle="tooltip" title="like">
																				<i class="ti-heart"></i>
																					<ins>'.mysqli_fetch_array($resultReact)['count(reactstat)'].'</ins></span></li>';
																}else{

																	$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																			<span class="like" data-toggle="tooltip" title="like">
																				<i class="ti-heart"></i>
																				<ins></ins>
																			</span>
																		</li>';
																}

																$sqlReact2 = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 2";
																$resultReact2 = mysqli_query($conn,$sqlReact2);
																if(mysqli_num_rows($resultReact2) != 0){
																		$data .= '<li class="clickbroken" broke="'.$row['p_id'].'">
																				<span class="dislike" data-toggle="tooltip" title="dislike">
																					<i class="ti-heart-broken"></i>
																					<ins>'.mysqli_fetch_array($resultReact2)['count(reactstat)'].'</ins></span></li>';
																}else{

																	$data .= '	<li class="clickbroken" broke="'.$row['p_id'].'">
																			<span class="dislike" data-toggle="tooltip" title="dislike">
																				<i class="ti-heart-broken"></i>
																				<ins></ins>
																			</span>
																		</li>';
																}
															$data .= '</ul>
														</div>
												<span>Comments</span>
												<hr>
												<ul class="we-comet newincomingcomment'.$row['p_id'].'" >';

					$sqlComment = "SELECT * FROM commentpost a JOIN account b ON a.acc_id = b.a_id WHERE a.p_id ='".$row['p_id']."' ORDER BY a.cp_id ASC ";
					$resultComment = mysqli_query($conn,$sqlComment);

					while($rowcomment = mysqli_fetch_array($resultComment)){
						$data .= '<li>
															<div class="comet-avatar">
																<img src="'.$rowcomment['aimage'].'" alt="">
															</div>
															<div class="we-comment">
																<div class="coment-head">
																	<h5><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowcomment['a_id'].'">'.$rowcomment['fname'].'</a></h5>
																	<span>'.$rowcomment['datecomment'].'</span>
																</div>
																<p>'.$rowcomment['commentMess'].'</p>
															</div>
														</li>';
						}
						$data .= '</ul></div><div class="form">
															 <textarea placeholder="Post your comment" class="comments'.$row['p_id'].'  txt userComment"  data-comment="'.$row['p_id'].'"></textarea>
																<div class="add-smiles" bounch='.$row['p_id'].' closeopen = "close">
																	<span class="em em-expressionless" title="add icon"></span>
																</div>
																<div class="smiles-bunch smile'.$row['p_id'].'">
																	<i class="em em---1 selecticon" emoji='.$row['p_id'].' icons="em---1"></i>
																	<i class="em em-smiley selecticon" emoji='.$row['p_id'].'  icons="em-smiley"></i>
																	<i class="em em-anguished selecticon" emoji='.$row['p_id'].'  icons="em-anguished"></i>
																	<i class="em em-laughing selecticon" emoji='.$row['p_id'].'  icons="em-laughing"></i>
																	<i class="em em-angry selecticon" emoji='.$row['p_id'].'  icons="em-angry"></i>
																	<i class="em em-astonished selecticon" emoji='.$row['p_id'].'  icons="em-astonished"></i>
																	<i class="em em-blush selecticon" emoji='.$row['p_id'].'  icons="em-blush"></i>
																	<i class="em em-disappointed selecticon" emoji='.$row['p_id'].'  icons="em-disappointed"></i>
																	<i class="em em-worried selecticon" emoji='.$row['p_id'].'  icons="em-worried"></i>
																	<i class="em em-kissing_heart selecticon" emoji='.$row['p_id'].'  icons="em-kissing_heart"></i>
																	<i class="em em-rage selecticon" emoji='.$row['p_id'].' icons="em-rage"></i>
																	<i class="em em-stuck_out_tongue selecticon" emoji='.$row['p_id'].'  icons="em-stuck_out_tongue"></i>
																</div>
															
														
															</div><hr><br/><br/>';
				}
			}

			echo $data;
		}
	
	}

	if(isset($_REQUEST['showAllImahe'])){
				
		$sql = "SELECT * FROM account a JOIN post_user b ON b.u_id = a.a_id WHERE b.u_id = '{$sessionId}' ORDER BY b.p_id DESC";
 		$resultLostPost = mysqli_query($conn,$sql);
		if(mysqli_num_rows($resultLostPost)!=0){
			while($row = mysqli_fetch_array($resultLostPost)){
				if($row['delstatus'] == 0){
				if($row['img_vid'] != '' && strpos($row['img_vid'],'.jpg') != false || strpos($row['img_vid'],'.png') != false  || strpos($row['img_vid'],'.gif') != false ){
					$data .= '<div class="friend-info">
													<figure>
														<img src="'.$row['aimage'].'" alt="">
													</figure>
													<div class="friend-name">
														<ins><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$row['a_id'].'">'.$row['fname'].'</a></ins>
														<span>published: '.$row['date_post'].'</span>
													</div>
								<div class="post-meta">
								<img src="'.$row['img_vid'].'" >
								<div class="description">
													<p>
																'.$row['caption'].'
															</p>
														</div>
													</div>
												</div>
												<div class="coment-area ">
									<div class="we-video-info">
									<ul>';
								$sqlchatcount = "SELECT count(a.p_id) FROM commentpost a WHERE a.p_id = '".$row['p_id']."' ";
									$resultchaatcount = mysqli_query($conn,$sqlchatcount);

																$data .= '<li>
																	<span class="comment" data-toggle="tooltip" title="Comments">
																		<i class="fa fa-comments-o"></i>
																		<ins>'. mysqli_fetch_array($resultchaatcount)['count(a.p_id)']
																		.'</ins>
																	</span>
																</li>';

																$sqlReact = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 1";
																$resultReact = mysqli_query($conn,$sqlReact);
																if(mysqli_num_rows($resultReact) != 0){
																		$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																				<span class="like" data-toggle="tooltip" title="like">
																				<i class="ti-heart"></i>
																					<ins>'.mysqli_fetch_array($resultReact)['count(reactstat)'].'</ins></span></li>';
																}else{

																	$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																			<span class="like" data-toggle="tooltip" title="like">
																				<i class="ti-heart"></i>
																				<ins></ins>
																			</span>
																		</li>';
																}

																$sqlReact2 = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 2";
																$resultReact2 = mysqli_query($conn,$sqlReact2);
																if(mysqli_num_rows($resultReact2) != 0){
																		$data .= '<li class="clickbroken" broke="'.$row['p_id'].'">
																				<span class="dislike" data-toggle="tooltip" title="dislike">
																					<i class="ti-heart-broken"></i>
																					<ins>'.mysqli_fetch_array($resultReact2)['count(reactstat)'].'</ins></span></li>';
																}else{

																	$data .= '	<li class="clickbroken" broke="'.$row['p_id'].'">
																			<span class="dislike" data-toggle="tooltip" title="dislike">
																				<i class="ti-heart-broken"></i>
																				<ins></ins>
																			</span>
																		</li>';
																}
															$data .= '</ul>
														</div>
												<span>Comments</span>
												<hr>
												<ul class="we-comet newincomingcomment'.$row['p_id'].'" >';

					$sqlComment = "SELECT * FROM commentpost a JOIN account b ON a.acc_id = b.a_id WHERE a.p_id ='".$row['p_id']."' ORDER BY a.cp_id ASC ";
					$resultComment = mysqli_query($conn,$sqlComment);

					while($rowcomment = mysqli_fetch_array($resultComment)){
						$data .= '<li>
															<div class="comet-avatar">
																<img src="'.$rowcomment['aimage'].'" alt="">
															</div>
															<div class="we-comment">
																<div class="coment-head">
																	<h5><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowcomment['a_id'].'">'.$rowcomment['fname'].'</a></h5>
																	<span>'.$rowcomment['datecomment'].'</span>
																</div>
																<p>'.$rowcomment['commentMess'].'</p>
															</div>
														</li>';
						}
						$data .= '</ul></div><div class="form">
															 <textarea placeholder="Post your comment" class="comments'.$row['p_id'].'  txt userComment"  data-comment="'.$row['p_id'].'"></textarea>
																<div class="add-smiles" bounch='.$row['p_id'].' closeopen = "close">
																	<span class="em em-expressionless" title="add icon"></span>
																</div>
																<div class="smiles-bunch smile'.$row['p_id'].'">
																	<i class="em em---1 selecticon" emoji='.$row['p_id'].' icons="em---1"></i>
																	<i class="em em-smiley selecticon" emoji='.$row['p_id'].'  icons="em-smiley"></i>
																	<i class="em em-anguished selecticon" emoji='.$row['p_id'].'  icons="em-anguished"></i>
																	<i class="em em-laughing selecticon" emoji='.$row['p_id'].'  icons="em-laughing"></i>
																	<i class="em em-angry selecticon" emoji='.$row['p_id'].'  icons="em-angry"></i>
																	<i class="em em-astonished selecticon" emoji='.$row['p_id'].'  icons="em-astonished"></i>
																	<i class="em em-blush selecticon" emoji='.$row['p_id'].'  icons="em-blush"></i>
																	<i class="em em-disappointed selecticon" emoji='.$row['p_id'].'  icons="em-disappointed"></i>
																	<i class="em em-worried selecticon" emoji='.$row['p_id'].'  icons="em-worried"></i>
																	<i class="em em-kissing_heart selecticon" emoji='.$row['p_id'].'  icons="em-kissing_heart"></i>
																	<i class="em em-rage selecticon" emoji='.$row['p_id'].' icons="em-rage"></i>
																	<i class="em em-stuck_out_tongue selecticon" emoji='.$row['p_id'].'  icons="em-stuck_out_tongue"></i>
																</div>
															
														
															</div><hr><br/><br/>';
				}
				}
			}
			echo $data;
		}

	}

	if(isset($_REQUEST['showAllVideo'])){

	$sql = "SELECT * FROM account a JOIN post_user b ON b.u_id = a.a_id WHERE b.u_id = '{$sessionId}' ORDER BY b.p_id DESC";
 		$resultLostPost = mysqli_query($conn,$sql);
		if(mysqli_num_rows($resultLostPost)!=0){
			while($row = mysqli_fetch_array($resultLostPost)){
				if($row['delstatus'] == 0){
				if($row['img_vid'] != '' && strpos($row['img_vid'],'.mp4') != false){
					$data .= '<div class="friend-info">
													<figure>
														<img src="'.$row['aimage'].'" alt="">
													</figure>
													<div class="friend-name">
														<ins><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$row['a_id'].'">'.$row['fname'].'</a></ins>
														<span>published: '.$row['date_post'].'</span>
													</div>
								<div class="post-meta">
								<video src = "'.$row['img_vid'].'" controls type="video/mp4" style="width:100%;>
								<div class="description">
													<p>
																'.$row['caption'].'
															</p>
														</div>
													</div>
												</div>
												<div class="coment-area ">
									<div class="we-video-info">
									<ul>';
								$sqlchatcount = "SELECT count(a.p_id) FROM commentpost a WHERE a.p_id = '".$row['p_id']."' ";
									$resultchaatcount = mysqli_query($conn,$sqlchatcount);

																$data .= '<li>
																	<span class="comment" data-toggle="tooltip" title="Comments">
																		<i class="fa fa-comments-o"></i>
																		<ins>'. mysqli_fetch_array($resultchaatcount)['count(a.p_id)']
																		.'</ins>
																	</span>
																</li>';

																$sqlReact = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 1";
																$resultReact = mysqli_query($conn,$sqlReact);
																if(mysqli_num_rows($resultReact) != 0){
																		$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																				<span class="like" data-toggle="tooltip" title="like">
																				<i class="ti-heart"></i>
																					<ins>'.mysqli_fetch_array($resultReact)['count(reactstat)'].'</ins></span></li>';
																}else{

																	$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																			<span class="like" data-toggle="tooltip" title="like">
																				<i class="ti-heart"></i>
																				<ins></ins>
																			</span>
																		</li>';
																}

																$sqlReact2 = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 2";
																$resultReact2 = mysqli_query($conn,$sqlReact2);
																if(mysqli_num_rows($resultReact2) != 0){
																		$data .= '<li class="clickbroken" broke="'.$row['p_id'].'">
																				<span class="dislike" data-toggle="tooltip" title="dislike">
																					<i class="ti-heart-broken"></i>
																					<ins>'.mysqli_fetch_array($resultReact2)['count(reactstat)'].'</ins></span></li>';
																}else{

																	$data .= '	<li class="clickbroken" broke="'.$row['p_id'].'">
																			<span class="dislike" data-toggle="tooltip" title="dislike">
																				<i class="ti-heart-broken"></i>
																				<ins></ins>
																			</span>
																		</li>';
																}
															$data .= '</ul>
														</div>
												<span>Comments</span>
												<hr>
												<ul class="we-comet newincomingcomment'.$row['p_id'].'" >';

					$sqlComment = "SELECT * FROM commentpost a JOIN account b ON a.acc_id = b.a_id WHERE a.p_id ='".$row['p_id']."' ORDER BY a.cp_id ASC ";
					$resultComment = mysqli_query($conn,$sqlComment);

					while($rowcomment = mysqli_fetch_array($resultComment)){
						$data .= '<li>
															<div class="comet-avatar">
																<img src="'.$rowcomment['aimage'].'" alt="">
															</div>
															<div class="we-comment">
																<div class="coment-head">
																	<h5><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowcomment['a_id'].'">'.$rowcomment['fname'].'</a></h5>
																	<span>'.$rowcomment['datecomment'].'</span>
																</div>
																<p>'.$rowcomment['commentMess'].'</p>
															</div>
														</li>';
						}
						$data .= '</ul></div><div class="form">
															 <textarea placeholder="Post your comment" class="comments'.$row['p_id'].'  txt userComment"  data-comment="'.$row['p_id'].'"></textarea>
																<div class="add-smiles" bounch='.$row['p_id'].' closeopen = "close">
																	<span class="em em-expressionless" title="add icon"></span>
																</div>
																<div class="smiles-bunch smile'.$row['p_id'].'">
																	<i class="em em---1 selecticon" emoji='.$row['p_id'].' icons="em---1"></i>
																	<i class="em em-smiley selecticon" emoji='.$row['p_id'].'  icons="em-smiley"></i>
																	<i class="em em-anguished selecticon" emoji='.$row['p_id'].'  icons="em-anguished"></i>
																	<i class="em em-laughing selecticon" emoji='.$row['p_id'].'  icons="em-laughing"></i>
																	<i class="em em-angry selecticon" emoji='.$row['p_id'].'  icons="em-angry"></i>
																	<i class="em em-astonished selecticon" emoji='.$row['p_id'].'  icons="em-astonished"></i>
																	<i class="em em-blush selecticon" emoji='.$row['p_id'].'  icons="em-blush"></i>
																	<i class="em em-disappointed selecticon" emoji='.$row['p_id'].'  icons="em-disappointed"></i>
																	<i class="em em-worried selecticon" emoji='.$row['p_id'].'  icons="em-worried"></i>
																	<i class="em em-kissing_heart selecticon" emoji='.$row['p_id'].'  icons="em-kissing_heart"></i>
																	<i class="em em-rage selecticon" emoji='.$row['p_id'].' icons="em-rage"></i>
																	<i class="em em-stuck_out_tongue selecticon" emoji='.$row['p_id'].'  icons="em-stuck_out_tongue"></i>
																</div>
															
														
															</div><hr><br/><br/>';
				}
				}
			}
			echo $data;
		}



	}


	if(isset($_REQUEST['upprofile'])){

		if(isset($_FILES['file']['name'])){
			$fileName = $_FILES['file']['name'];

			$location = '../imageVideo/'.$fileName;

			$fileExtenxsion = pathinfo($location,PATHINFO_EXTENSION);
			$fileExtenxsion = strtolower($fileExtenxsion);

			$validEx = array("jpg","png","jpeg");

			if(in_array($fileExtenxsion, $validEx)){
				if(move_uploaded_file($_FILES['file']['tmp_name'], $location)){
						
				$file = 'imageVideo/'.$fileName.'';
				$savePost = "INSERT INTO post_user (u_id,img_vid,date_post,delstatus) values('{$idkoidmo}','{$file}','{$datePost}',0)";
					$resultSavePost = mysqli_query($conn,$savePost);

				$profileupdate = "UPDATE `account` SET aimage= '{$file}' WHERE a_id = '{$idkoidmo}'";
				$upprof = mysqli_query($conn,$profileupdate);

				}
			}
		}
	}

	if(isset($_REQUEST['upbackground'])){

		if(isset($_FILES['file']['name'])){
			$fileName = $_FILES['file']['name'];

			$location = '../imageVideo/'.$fileName;

			$fileExtenxsion = pathinfo($location,PATHINFO_EXTENSION);
			$fileExtenxsion = strtolower($fileExtenxsion);

			$validEx = array("jpg","png","jpeg");

			if(in_array($fileExtenxsion, $validEx)){
				if(move_uploaded_file($_FILES['file']['tmp_name'], $location)){
						
				$file = 'imageVideo/'.$fileName.'';
				$savePost = "INSERT INTO post_user (u_id,img_vid,date_post,delstatus) values('{$idkoidmo}','{$file}','{$datePost}',0)";
					$resultSavePost = mysqli_query($conn,$savePost);

				$profileupdate = "UPDATE `account` SET bimage= '{$file}' WHERE a_id = '{$idkoidmo}'";
				$upprof = mysqli_query($conn,$profileupdate);

				}
			}
		}
	}

	if(isset($_REQUEST['userFname'])){
		$sql ="SELECT * FROM account WHERE a_id = '{$sessionId}' ";
		$r = mysqli_query($conn,$sql);
		echo mysqli_fetch_array($r)['fname'];
	}

	if(isset($_REQUEST['postnews'])){
		$sql = "SELECT * FROM post_user a JOIN account b ON a.u_id = b.a_id WHERE a.u_id = '{$sessionId}' ";
		$q = mysqli_query($conn,$sql);
		if(mysqli_num_rows($q)!=0){
			while($r = mysqli_fetch_array($q)){
				if($r['delstatus'] == 0){
					$pid = $r['p_id'];

					$sql2 = "SELECT * FROM commentpostnotification WHERE cid = '{$pid}' AND replayid != '{$sessionId}' AND stat = 1";
					$q2 = mysqli_query($conn,$sql2);

					if(mysqli_num_rows($q2)!=0){
						$b = '<div style="border:1px solid none;text-align:center;float:right;background:green;color:white;">New message</div>' ;
						$data .= '<li class="comment-meta" dataid ="'.$r['p_id'].'" post-id = "'.$r['p_id'].'">
										<a href="notification.html">
											<img src="'.$r['aimage'].'" alt="">
											<div class="mesg-meta">
												<h6>'.$r['fname'].'</h6>';
												
												if($r['img_vid']!='' && strpos($r['img_vid'],'.jpg') != false || strpos($r['img_vid'],'.png') != false  || strpos($r['img_vid'],'.gif') != false){
													$data .= '<img src="'.$r['img_vid'].'" style="height:40px;">';
												}else if($r['img_vid'] != '' && strpos($r['img_vid'],'.mp4') != false){
													$data .= '<video src = "'.$r['img_vid'].'" type="video/mp4" style="height:20px;width:20px">';
												}		

													$data .= '<br/>'.$r['caption'] == '' ? '' :  '<i>'.$r['caption'].'</i><br/>'.'<i>'.$r['date_post']
													.'  '.$b.'</i>
										</div>
									</a>
							</li>';
					}else{
						$data .= '<li class="comment-meta" dataid ="'.$r['p_id'].'" post-id = "'.$r['p_id'].'">
										<a href="notification.html">
											<img src="'.$r['aimage'].'" alt="">
											<div class="mesg-meta">
												<h6>'.$r['fname'].'</h6>';
												
												if($r['img_vid']!='' && strpos($r['img_vid'],'.jpg') != false || strpos($r['img_vid'],'.png') != false  || strpos($r['img_vid'],'.gif') != false){
													$data .= '<img src="'.$r['img_vid'].'" style="height:40px;">';
												}else if($r['img_vid'] != '' && strpos($r['img_vid'],'.mp4') != false){
													$data .= '<video src = "'.$r['img_vid'].'" type="video/mp4" style="height:20px;width:20px">';
												}		

													$data .= '<br/>'.$r['caption'] == '' ? '' :  '<i>'.$r['caption'].'</i><br/>'.'<i>'.$r['date_post']
													.'  '.'</i>
										</div>
									</a>
							</li>';
					}
					
				}
			}
			echo $data;
		}
	}

	if(isset($_REQUEST['repostnews'])){
			$sql = "SELECT * FROM post_user a JOIN account b ON a.u_id = b.a_id WHERE a.u_id = '{$sessionId}' ";
		$q = mysqli_query($conn,$sql);
		if(mysqli_num_rows($q)!=0){
			$a = 0;
			while($r = mysqli_fetch_array($q)){
				$pid = $r['p_id'];
				if($r['delstatus']==0){
					$sql2 = "SELECT count(*) FROM commentpostnotification WHERE cid = '{$pid}' AND replayid != '{$sessionId}' AND stat = 1 ";
					$q2 = mysqli_query($conn,$sql2);
					$a += mysqli_fetch_array($q2)['count(*)'];
				}
			}
			echo $a;
		}
	}

	if(isset($_REQUEST['frequest'])){
		$sql = "SELECT * FROM friendlist a JOIN account b ON a.accid = b.a_id WHERE a.follower = '{$sessionId}' AND a.stat = 0 ";
		$q = mysqli_query($conn,$sql);
		if(mysqli_num_rows($q)!=0){
			while ($r = mysqli_fetch_array($q)) {
				$data .= '<li class="li-request'.$r['fid'].'">
							<div class="nearly-pepls">
								<figure>
									<a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'"><img src="'.$r['aimage'].'" alt=""></a>
								</figure>
								<div class="pepl-info">
									<h4><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'">'.$r['fname'].'</a></h4>
									<a title="" class="add-butn _deletereq more-action" data-ripple="" dataid="'.$r['fid'].'" style="cursor:pointer;color:white;">delete Request</a>
									<a title="" class="add-butn _confirm confirm" data-ripple="" dataid="'.$r['fid'].'" style="cursor:pointer;color:white;">Confirm</a>
								</div>
							</div>
						</li>';
			}
			echo $data;
		}
	}

	if(isset($_REQUEST['countfriendsrequest'])){
		$sql = "SELECT count(*) FROM friendlist a JOIN account b ON a.accid = b.a_id WHERE a.follower = '{$sessionId}' AND a.stat = 0 ";
		$q = mysqli_query($conn,$sql);
		$a=0;
		$a += mysqli_fetch_array($q)['count(*)'];
		echo $a;
	}

	if(isset($_REQUEST['deleteFriendRequest'])){
		$sql = "SELECT * FROM friendlist WHERE fid = '{$fid}' ";
		$q = mysqli_query($conn,$sql);
		if(mysqli_num_rows($q)!=0){
			$sql2 = "DELETE FROM friendlist WHERE fid = '{$fid}' ";
			$q2 = mysqli_query($conn,$sql2);	
		}
		
	}


	if(isset($_REQUEST['confirmFriendRequest'])){
		$sql = "UPDATE friendlist SET stat= 1 WHERE fid = '{$fid}' ";
		$q = mysqli_query($conn,$sql);
	}


	if(isset($_REQUEST['myfriends'])){
		$sql = "SELECT * FROM account WHERE a_id != '{$sessionId}' ";
		$q = mysqli_query($conn,$sql);
			if(mysqli_num_rows($q)!=0){
				while ($r = mysqli_fetch_array($q)) {	
					$followerid = $r['a_id'];
					$sql2 = "SELECT * FROM friendlist a WHERE a.accid = '{$sessionId}' AND a.follower = '{$followerid}' OR a.accid = '{$followerid}' AND a.follower = '{$sessionId}'  ";
					$q2 = mysqli_query($conn,$sql2);
					$q3 = mysqli_query($conn,$sql2);
					if(mysqli_num_rows($q2) != 0){
						if(mysqli_fetch_array($q2)['stat'] == 1){
						$fid = mysqli_fetch_array($q3)['fid'];
						$data .= '<li class="li-myfriends'.$fid.'">
									<div class="nearly-pepls">
										<figure>
											<a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'"><img src="'.$r['aimage'].'" alt=""></a>
										</figure>
										<div class="pepl-info">
											<h4><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'">'.$r['fname'].'</a></h4>
												<a title="" class="add-butn _unfriend more-action" data-ripple="" dataid="'.$fid.'" style="cursor:pointer;color:white;">Unfriend</a>
										</div>
									</div>
							</li>';
						}
					}
			}
			echo $data;
		}
	}

	if(isset($_REQUEST['myfriendsview'])){
	$sql = "SELECT * FROM account WHERE a_id != '{$sessionId}' ";
		$q = mysqli_query($conn,$sql);
			if(mysqli_num_rows($q)!=0){
				while ($r = mysqli_fetch_array($q)) {	
					$followerid = $r['a_id'];
					$sql2 = "SELECT * FROM friendlist a WHERE a.accid = '{$sessionId}' AND a.follower = '{$followerid}' OR a.accid = '{$followerid}' AND a.follower = '{$sessionId}'  ";
					$q2 = mysqli_query($conn,$sql2);
					$q3 = mysqli_query($conn,$sql2);
					if(mysqli_num_rows($q2) != 0){
						if(mysqli_fetch_array($q2)['stat'] == 1){
						$fid = mysqli_fetch_array($q3)['fid'];
						$data .= '<li class="li-myfriends'.$fid.'">
									<div class="nearly-pepls">
										<figure>
											<a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'"><img src="'.$r['aimage'].'" alt=""></a>
										</figure>
										<div class="pepl-info">
											<h4>
												<a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'">'.$r['fname'].'</a>
											</h4>
										</div>
									</div>
							</li>';
						}
					}
			}
			echo $data;
		}
	}
	if(isset($_REQUEST['myfriendsview2'])){

		$sql2 = "SELECT * FROM friendlist a WHERE a.accid = '{$myid}' AND a.follower = '{$sessionId}' OR a.accid = '{$sessionId}' AND a.follower = '{$myid}'  ";
			$q2 = mysqli_query($conn,$sql2);
			if(mysqli_num_rows($q2) != 0){
				while($row = mysqli_fetch_array($q2)){
					if($row['stat'] == 1){
						$data .= '<a title="" class="add-butn _unfriend2 more-action" data-ripple="" dataid="'.$row['fid'].'" style="cursor:pointer;color:white;">Unfriend</a>';
					}else{
						$data .= '<div class="confirmaddfriend"><a title="" class="add-butn _deletereq2 more-action" data-ripple="" dataid="'.$row['fid'].'" style="cursor:pointer;color:white;">delete Request</a>
									<a title="" class="add-butn _confirm2 confirm" data-ripple="" dataid="'.$row['fid'].'" style="cursor:pointer;color:white;">Confirm</a></div>';
					}
				}
			}else{
					$data .= '<a title="" class="add-butn _addfriend3" data-ripple="" dataid="'.$sessionId.'" style="cursor:pointer;color:white;">Addfriend</a>';
				
			}
		echo $data;
	}

	if(isset($_REQUEST['countmyfriends'])){
		$sql = "SELECT * FROM account WHERE a_id != '{$sessionId}' ";
		$q = mysqli_query($conn,$sql);
			if(mysqli_num_rows($q)!=0){
				$a = 0;
				while ($r = mysqli_fetch_array($q)) {	
					$followerid = $r['a_id'];
					$sql2 = "SELECT count(*),a.stat FROM friendlist a WHERE a.accid = '{$sessionId}' AND a.follower = '{$followerid}' OR a.accid = '{$followerid}' AND a.follower = '{$sessionId}' ";
					$q2 = mysqli_query($conn,$sql2);
					$q3 = mysqli_query($conn,$sql2);
					if(mysqli_fetch_array($q3)['stat'] == 1){
						$a +=  mysqli_fetch_array($q2)['count(*)'];
					}
					
				}
				echo $a;

			}
	}
	if(isset($_REQUEST['addafriends'])){
		$sql2 = "SELECT * FROM friendlist a JOIN account b ON a.accid = b.a_id WHERE a.accid = '{$myid}' AND a.follower = '{$sessionId}' OR a.accid = '{$sessionId}' AND a.follower = '{$myid}' ";
			$q2 = mysqli_query($conn,$sql2);
			if(mysqli_num_rows($q2) == 0){
				$data.= '<a title="" class="add-butn _addfriend2" data-ripple="" dataid="'.$r['a_id'].'" style="cursor:pointer;color:white;">Add friend</a>';
			}
	}
	if(isset($_REQUEST['findfriends'])){
		$sql = "SELECT * FROM account WHERE a_id != '{$sessionId}' ";
		$q = mysqli_query($conn,$sql);
			if(mysqli_num_rows($q)!=0){
				while ($r = mysqli_fetch_array($q)) {	
					$followerid = $r['a_id'];
					$sql2 = "SELECT * FROM friendlist a WHERE a.accid = '{$sessionId}' AND a.follower = '{$followerid}' OR a.accid = '{$followerid}' AND a.follower = '{$sessionId}' ";
					$q2 = mysqli_query($conn,$sql2);
					if(mysqli_num_rows($q2) == 0){
						$data .= '<li class="li-addfriend'.$r['a_id'].'">
										<div class="nearly-pepls">
											<figure>
												<a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'"><img src="'.$r['aimage'].'" alt=""></a>
											</figure>
												<div class="pepl-info">
													<h4><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$r['a_id'].'">'.$r['fname'].'</a></h4>
													<a title="" class="add-butn _addfriend" data-ripple="" dataid="'.$r['a_id'].'" style="cursor:pointer;color:white;">Add friend</a>
												</div>
										</div>
								</li>';
					}
				}
				echo $data;
			}	
	}

	if(isset($_REQUEST['addfindfriends'])){
		$sql = "SELECT * FROM friendlist WHERE accid = '{$sessionId}' AND follower = '{$aid}' OR accid = '{$aid}' AND follower ='{$sessionId}' ";
		$q = mysqli_query($conn,$sql);
		if(mysqli_num_rows($q)==0){
			$sql2 = "INSERT INTO friendlist(accid,follower,stat) VALUES ('{$sessionId}',{$aid},0)";
			$q2 = mysqli_query($conn,$sql2);
		}
	}

	if(isset($_REQUEST['changepass'])){
		$sql2 = "UPDATE `account` SET password = '{$pass1}'  WHERE  a_id = '{$sessionId}' ";
		$resultchat2 = mysqli_query($conn,$sql2);	
	}

	if(isset($_REQUEST['changename'])){
		$sql2 = "UPDATE `account` SET fname = '{$fname}', lname = '{$lname}'  WHERE  a_id = '{$sessionId}' ";
		$resultchat2 = mysqli_query($conn,$sql2);	
	}

	if(isset($_REQUEST['register'])){
		$sql = "SELECT * FROM account WHERE username = '{$username}' ";
		$q = mysqli_query($conn,$sql);
		if(mysqli_num_rows($q)==0){
			$sql2 = "INSERT INTO account(username,password,fname,lname,aimage,bimage,gender) VALUES ('{$username}','{$password}','{$fname}','{$lname}','imageVideo/btm-baner-avatar.png','imageVideo/btm-baner-avatar.png','{$gender}')";
			$q2 = mysqli_query($conn,$sql2);
			$sql3 = "SELECT * FROM account WHERE username = '{$username}' ";
			$sq3 = mysqli_query($conn,$sql3);
			echo mysqli_fetch_array($sq3)['a_id'];
		}else{
			echo null;
		}
	}

?>
