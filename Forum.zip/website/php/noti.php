<?php
$conn = mysqli_connect('localhost','root','','socialnetwork');
    if(!$conn){die('Error:' .mysqli_error($conn));}
    $data = '';
    extract($_REQUEST);
    $array = array();

	if(isset($_REQUEST['noti'])){
		$sql = "SELECT * FROM account a JOIN post_user b ON b.u_id = a.a_id where b.p_id = '{$postid}' ORDER BY b.p_id DESC";
	 		$resultLostPost = mysqli_query($conn,$sql);
	if(mysqli_num_rows($resultLostPost)!=0){
		while($row = mysqli_fetch_array($resultLostPost)){
			if($row['delstatus'] == 0){
				$data .= '<div class="friend-info">
												<figure>
													<img src="'.$row['aimage'].'" alt="">
												</figure>
												<div class="friend-name">
													<ins><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$row['a_id'].'">'.$row['fname'].'</a></ins>
													<span>published: '.$row['date_post'].'</span>
												</div>
							<div class="post-meta">';
					if($row['img_vid']!='' && strpos($row['img_vid'],'.jpg') != false || strpos($row['img_vid'],'.png') != false  || strpos($row['img_vid'],'.gif') != false){
						$data .= '<img src="'.$row['img_vid'].'">';
					}else if($row['img_vid'] != '' && strpos($row['img_vid'],'.mp4') != false){
						$data .= '<video src = "'.$row['img_vid'].'" controls type="video/mp4" style="width:100%;>';
					}		

						$data .= '<div class="description">
														
														<p>
															'.$row['caption'].'
														</p>
													</div>
												</div>
											</div>
											<div class="coment-area ">
								<div class="we-video-info">
								<ul>';
							$sqlchatcount = "SELECT count(a.p_id) FROM commentpost a WHERE a.p_id = '".$row['p_id']."' ";
								$resultchaatcount = mysqli_query($conn,$sqlchatcount);

															$data .= '<li>
																<span class="comment" data-toggle="tooltip" title="Comments">
																	<i class="fa fa-comments-o"></i>
																	<ins>'. mysqli_fetch_array($resultchaatcount)['count(a.p_id)']
																	.'</ins>
																</span>
															</li>';

															$sqlReact = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 1";
															$resultReact = mysqli_query($conn,$sqlReact);
															if(mysqli_num_rows($resultReact) != 0){
																	$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																			<span class="like" data-toggle="tooltip" title="like">
																			<i class="ti-heart"></i>
																				<ins>'.mysqli_fetch_array($resultReact)['count(reactstat)'].'</ins></span></li>';
															}else{

																$data .= '<li class="clickheart" heart="'.$row['p_id'].'">
																		<span class="like" data-toggle="tooltip" title="like">
																			<i class="ti-heart"></i>
																			<ins></ins>
																		</span>
																	</li>';
															}

															$sqlReact2 = "SELECT count(reactstat) FROM reactpost WHERE postidreact = '".$row['p_id']."' AND reactstat = 2";
															$resultReact2 = mysqli_query($conn,$sqlReact2);
															if(mysqli_num_rows($resultReact2) != 0){
																	$data .= '<li class="clickbroken" broke="'.$row['p_id'].'">
																			<span class="dislike" data-toggle="tooltip" title="dislike">
																				<i class="ti-heart-broken"></i>
																				<ins>'.mysqli_fetch_array($resultReact2)['count(reactstat)'].'</ins></span></li>';
															}else{

																$data .= '	<li class="clickbroken" broke="'.$row['p_id'].'">
																		<span class="dislike" data-toggle="tooltip" title="dislike">
																			<i class="ti-heart-broken"></i>
																			<ins></ins>
																		</span>
																	</li>';
															}
														$data .= '</ul>
													</div>
											<span>Comments</span>
											<hr>
											<ul class="we-comet newincomingcomment'.$row['p_id'].'" >';

				$sqlComment = "SELECT * FROM commentpost a JOIN account b ON a.acc_id = b.a_id WHERE a.p_id ='".$row['p_id']."' ORDER BY a.cp_id ASC ";
				$resultComment = mysqli_query($conn,$sqlComment);

				while($rowcomment = mysqli_fetch_array($resultComment)){
					$data .= '<li>
														<div class="comet-avatar">
															<img src="'.$rowcomment['aimage'].'" alt="">
														</div>
														<div class="we-comment">
															<div class="coment-head">
																<h5><a href="viewtimeline.html" title="" class="viewtimeline" dataid = "'.$rowcomment['a_id'].'">'.$rowcomment['fname'].'</a></h5>
																<span>'.$rowcomment['datecomment'].'</span>
															</div>
															<p>'.$rowcomment['commentMess'].'</p>
														</div>
													</li>';
					}
					$data .= '</ul></div><div class="form">
														 <textarea placeholder="Post your comment" class="comments'.$row['p_id'].'  txt userComment"  data-comment="'.$row['p_id'].'"></textarea>
															<div class="add-smiles" bounch='.$row['p_id'].' closeopen = "close">
																<span class="em em-expressionless" title="add icon"></span>
															</div>
															<div class="smiles-bunch smile'.$row['p_id'].'">
																<i class="em em---1 selecticon" emoji='.$row['p_id'].' icons="em---1"></i>
																<i class="em em-smiley selecticon" emoji='.$row['p_id'].'  icons="em-smiley"></i>
																<i class="em em-anguished selecticon" emoji='.$row['p_id'].'  icons="em-anguished"></i>
																<i class="em em-laughing selecticon" emoji='.$row['p_id'].'  icons="em-laughing"></i>
																<i class="em em-angry selecticon" emoji='.$row['p_id'].'  icons="em-angry"></i>
																<i class="em em-astonished selecticon" emoji='.$row['p_id'].'  icons="em-astonished"></i>
																<i class="em em-blush selecticon" emoji='.$row['p_id'].'  icons="em-blush"></i>
																<i class="em em-disappointed selecticon" emoji='.$row['p_id'].'  icons="em-disappointed"></i>
																<i class="em em-worried selecticon" emoji='.$row['p_id'].'  icons="em-worried"></i>
																<i class="em em-kissing_heart selecticon" emoji='.$row['p_id'].'  icons="em-kissing_heart"></i>
																<i class="em em-rage selecticon" emoji='.$row['p_id'].' icons="em-rage"></i>
																<i class="em em-stuck_out_tongue selecticon" emoji='.$row['p_id'].'  icons="em-stuck_out_tongue"></i>
															</div>
														
													
														</div><hr><br/><br/>';
			}
		}
		echo $data;
		}
	}


?>